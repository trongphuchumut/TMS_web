# chatbot_v2/contracts/constants.py
from __future__ import annotations
from typing import Literal

# ===== Session =====
SESSION_KEY = "chatbot_v2_state"

# ===== Limits =====
MAX_HISTORY = 20
FUZZY_TTL_TURNS = 3

# ===== Routing thresholds =====
INTENT_CONF_THRESHOLD = 0.58  # dưới mức này thì fallback hỏi lại

# ===== Enums (string literals) =====
Role = Literal["user", "bot"]

Stage = Literal[
    "IDLE",
    "COLLECTING",
    "CONFIRMING",
    "SCORING",
    "PRESENTING",
]

RouteKind = Literal["case", "intent"]

CaseType = Literal[
    "RESET",
    "CANCEL",
    "CONFIRM_YES",
    "CONFIRM_NO",
    "AMBIGUOUS_CONFIRM",
    "SELECT",
    "ADD_INFO",
    "ASK_EXPLAIN",
]

IntentType = Literal[
    "smalltalk_faq",
    "search_device",
    "fuzzy_suggest",
    "clarify",
]

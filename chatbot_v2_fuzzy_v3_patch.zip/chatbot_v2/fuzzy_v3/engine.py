# chatbot_v2/fuzzy_v3/engine.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple

Number = float

def clamp(x: Number, lo: Number=0.0, hi: Number=10.0) -> Number:
    return lo if x < lo else hi if x > hi else x

def tri(x: Number, a: Number, b: Number, c: Number) -> Number:
    """Triangular membership: 0 at a/c, 1 at b."""
    if x <= a or x >= c:
        return 0.0
    if x == b:
        return 1.0
    if x < b:
        return (x - a) / (b - a)
    return (c - x) / (c - b)

def grade(x: Number, a: Number, b: Number) -> Number:
    """Rising ramp: 0 at <=a, 1 at >=b."""
    if x <= a:
        return 0.0
    if x >= b:
        return 1.0
    return (x - a) / (b - a)

def reverse_grade(x: Number, a: Number, b: Number) -> Number:
    """Falling ramp: 1 at <=a, 0 at >=b."""
    if x <= a:
        return 1.0
    if x >= b:
        return 0.0
    return (b - x) / (b - a)

@dataclass
class FuzzyInputs:
    # 0..10
    cost_level: Number                 # 0 rất rẻ, 10 rất đắt (mức giá người dùng chấp nhận / đang muốn)
    durability_importance: Number      # 0 không quan tâm, 10 cực kỳ ưu tiên
    precision_importance: Number       # 0 không quan tâm, 10 cực kỳ ưu tiên
    speed_importance: Number           # 0 không quan tâm, 10 cực kỳ ưu tiên

    # optional structured constraints
    material: Optional[str] = None
    machining: Optional[str] = None
    diameter_mm: Optional[Number] = None
    notes: Optional[str] = None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "cost_level": float(self.cost_level),
            "durability_importance": float(self.durability_importance),
            "precision_importance": float(self.precision_importance),
            "speed_importance": float(self.speed_importance),
            "material": self.material,
            "machining": self.machining,
            "diameter_mm": float(self.diameter_mm) if self.diameter_mm is not None else None,
            "notes": self.notes,
        }

def normalize_candidate_values(values: List[Number]) -> List[Number]:
    """Normalize arbitrary numeric list into 0..10. If constant, return mid."""
    if not values:
        return []
    lo, hi = min(values), max(values)
    if hi - lo < 1e-9:
        return [5.0 for _ in values]
    return [ (v - lo) / (hi - lo) * 10.0 for v in values ]

def score_candidates(
    inputs: FuzzyInputs,
    candidates: List[Dict[str, Any]],
    *,
    feature_keys: Dict[str, str] | None = None,
) -> List[Dict[str, Any]]:
    """
    Deterministic scoring (fuzzy-ish but hardcoded):
    candidates: list of dicts, each should include features:
      - price_level (higher = more expensive) OR raw price
      - durability_level (higher = bền)
      - precision_level (higher = chính xác)
      - speed_level (higher = nhanh)
    feature_keys: allow remapping keys if your model uses other names.
    Returns list with added fields: score(0..100), reason_breakdown.
    """
    fk = feature_keys or {}
    k_price = fk.get("price_level", "price_level")
    k_price_raw = fk.get("price", "price")
    k_dur = fk.get("durability_level", "durability_level")
    k_pre = fk.get("precision_level", "precision_level")
    k_spd = fk.get("speed_level", "speed_level")

    # If price_level missing but raw price present, auto-normalize raw price across candidates.
    price_levels: List[Optional[Number]] = []
    raw_prices: List[Optional[Number]] = []
    for c in candidates:
        if k_price in c and c[k_price] is not None:
            price_levels.append(float(c[k_price]))
            raw_prices.append(None)
        elif k_price_raw in c and c[k_price_raw] is not None:
            price_levels.append(None)
            raw_prices.append(float(c[k_price_raw]))
        else:
            price_levels.append(None)
            raw_prices.append(None)

    if any(v is not None for v in raw_prices) and not any(v is not None for v in price_levels):
        norm = normalize_candidate_values([v for v in raw_prices if v is not None])
        it = iter(norm)
        for i, rp in enumerate(raw_prices):
            if rp is not None:
                price_levels[i] = next(it)

    out: List[Dict[str, Any]] = []

    # Convert user "cost_level" into a preference curve:
    # - user_cost_low means họ muốn rẻ; user_cost_high means họ chấp nhận đắt.
    user_cost = clamp(inputs.cost_level)

    # weights driven by importance (0..10) -> (0.2..1.0)
    w_dur = 0.2 + 0.8 * clamp(inputs.durability_importance) / 10.0
    w_pre = 0.2 + 0.8 * clamp(inputs.precision_importance) / 10.0
    w_spd = 0.2 + 0.8 * clamp(inputs.speed_importance) / 10.0
    # cost is always considered but less dominant by default
    w_cost = 0.35

    w_sum = w_cost + w_dur + w_pre + w_spd

    for idx, c in enumerate(candidates):
        price_level = price_levels[idx] if price_levels[idx] is not None else 5.0
        dur = float(c.get(k_dur) or 5.0)
        pre = float(c.get(k_pre) or 5.0)
        spd = float(c.get(k_spd) or 5.0)

        price_level = clamp(price_level)
        dur = clamp(dur)
        pre = clamp(pre)
        spd = clamp(spd)

        # membership: how well candidate matches user's "acceptable cost level"
        # Use a triangle around user_cost with width ±3.5
        m_cost = tri(price_level, clamp(user_cost-3.5), user_cost, clamp(user_cost+3.5))
        # durability/precision/speed: higher is better, so use grade (ramp) from 4..8
        m_dur = grade(dur, 4.0, 8.0)
        m_pre = grade(pre, 4.0, 8.0)
        m_spd = grade(spd, 4.0, 8.0)

        score_0_1 = (w_cost*m_cost + w_dur*m_dur + w_pre*m_pre + w_spd*m_spd) / w_sum
        score = round(score_0_1 * 100.0, 2)

        out.append({
            **c,
            "_fuzzy": {
                "score": score,
                "membership": {
                    "cost": round(m_cost, 4),
                    "durability": round(m_dur, 4),
                    "precision": round(m_pre, 4),
                    "speed": round(m_spd, 4),
                },
                "weights": {
                    "cost": round(w_cost, 4),
                    "durability": round(w_dur, 4),
                    "precision": round(w_pre, 4),
                    "speed": round(w_spd, 4),
                },
                "user_inputs": inputs.as_dict(),
                "candidate_inputs": {
                    "price_level": float(price_level),
                    "durability_level": float(dur),
                    "precision_level": float(pre),
                    "speed_level": float(spd),
                }
            }
        })

    out.sort(key=lambda x: x.get("_fuzzy", {}).get("score", 0.0), reverse=True)
    return out

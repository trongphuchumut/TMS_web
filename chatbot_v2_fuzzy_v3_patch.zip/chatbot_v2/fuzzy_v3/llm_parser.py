# chatbot_v2/fuzzy_v3/llm_parser.py
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from ..integrations.ai import call_ai
from .engine import FuzzyInputs, clamp

FUZZY_PARSE_SYSTEM_PROMPT = r"""
Bạn là "Fuzzy Preference Extractor" cho chatbot TMS.
Nhiệm vụ: đọc lời người dùng (tiếng Việt) và trích xuất *thông số fuzzy dạng số 0..10*.

QUY TẮC CHUNG
- Luôn trả về JSON hợp lệ, KHÔNG kèm text ngoài JSON.
- Không suy đoán bừa: nếu thiếu dữ kiện quan trọng, đánh dấu missing_fields và đặt need_more_info=true.
- Ưu tiên hiểu theo ngữ cảnh: người dùng có thể trả lời rời rạc, bổ sung dần.
- Scale 0..10:
  * cost_level: 0 = rất rẻ, 10 = rất đắt (mức giá người dùng đang muốn/chấp nhận)
  * importance: 0 = không quan tâm, 10 = ưu tiên tuyệt đối
- Map ví dụ (cost_level):
  "rất rẻ"=1, "khá rẻ"=3, "rẻ"=2-3, "tầm trung"=5,
  "hơi đắt"=7, "đắt"=8, "rất đắt"=9-10
- Map ví dụ (importance):
  "không quan trọng"=1, "bình thường"=4-5, "ưu tiên"=7, "rất quan trọng"=9

TRƯỜNG THÔNG TIN CẦN TRẢ
{
  "status": "ok" | "need_more_info",
  "domain": "tool" | "holder" | "unknown",
  "inputs": {
    "cost_level": number(0..10) or null,
    "durability_importance": number(0..10) or null,
    "precision_importance": number(0..10) or null,
    "speed_importance": number(0..10) or null,
    "material": string or null,
    "machining": string or null,
    "diameter_mm": number or null,
    "notes": string or null
  },
  "missing_fields": [string],
  "clarifying_question": string|null,
  "confidence": 0..1
}

GỢI Ý hỏi thêm (nếu thiếu):
- "Bạn ưu tiên giá rẻ hay độ bền/chính xác?"
- "Gia công vật liệu gì, và đường kính/chiều dài dao khoảng bao nhiêu?"
"""

def _json_safe_load(s: str) -> Dict[str, Any]:
    # cố gắng cắt phần JSON nếu model lỡ nói thêm
    s = (s or "").strip()
    if not s:
        return {}
    if "```" in s:
        s = s.split("```")[1] if len(s.split("```")) > 1 else s
    # tìm đoạn bắt đầu bằng { và kết thúc }
    start = s.find("{")
    end = s.rfind("}")
    if start != -1 and end != -1 and end > start:
        s = s[start:end+1]
    return json.loads(s)

def parse_fuzzy_inputs(user_message: str, *, model: Optional[str]=None, prior: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    """
    Return dict with keys: status, inputs(FuzzyInputs or partial dict), missing_fields, clarifying_question, confidence
    prior: previous extracted inputs to allow incremental fill.
    """
    prior = prior or {}
    prompt = FUZZY_PARSE_SYSTEM_PROMPT + "\n\n" + "USER_MESSAGE:\n" + user_message + "\n\n" + "PRIOR_JSON:\n" + json.dumps(prior, ensure_ascii=False)
    raw = call_ai(prompt, model=model)

    try:
        obj = _json_safe_load(raw)
    except Exception:
        obj = {}

    status = obj.get("status") or "need_more_info"
    dom = obj.get("domain") or "unknown"
    inputs = obj.get("inputs") or {}
    missing = obj.get("missing_fields") or []
    question = obj.get("clarifying_question")
    conf = float(obj.get("confidence") or 0.4)

    # Merge with prior (user may provide incremental info)
    merged = dict(prior)
    merged.update({k:v for k,v in inputs.items() if v not in (None, "", [])})

    def num(k, default=None):
        v = merged.get(k, default)
        if v is None:
            return None
        try:
            return clamp(float(v))
        except Exception:
            return None

    fin = {
        "cost_level": num("cost_level"),
        "durability_importance": num("durability_importance"),
        "precision_importance": num("precision_importance"),
        "speed_importance": num("speed_importance"),
        "material": merged.get("material"),
        "machining": merged.get("machining"),
        "diameter_mm": num("diameter_mm", None),
        "notes": merged.get("notes"),
    }

    # Determine missing: require 4 numeric to run ranking well
    required = ["cost_level", "durability_importance", "precision_importance", "speed_importance"]
    missing2 = [k for k in required if fin.get(k) is None]
    if missing2:
        status = "need_more_info"
        missing = list(dict.fromkeys(missing2 + list(missing)))

    return {
        "status": status,
        "domain": dom,
        "inputs": fin,
        "missing_fields": missing,
        "clarifying_question": question,
        "confidence": max(0.0, min(conf, 1.0)),
        "raw": raw,
    }

def build_inputs(fin: Dict[str, Any]) -> FuzzyInputs:
    return FuzzyInputs(
        cost_level=float(fin.get("cost_level") or 5.0),
        durability_importance=float(fin.get("durability_importance") or 5.0),
        precision_importance=float(fin.get("precision_importance") or 5.0),
        speed_importance=float(fin.get("speed_importance") or 5.0),
        material=fin.get("material"),
        machining=fin.get("machining"),
        diameter_mm=fin.get("diameter_mm"),
        notes=fin.get("notes"),
    )

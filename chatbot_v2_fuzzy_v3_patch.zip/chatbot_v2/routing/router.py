# chatbot_v2/routing/router.py
from __future__ import annotations

import re
from typing import Optional, Tuple

from ..contracts.types import SessionState, RouteResult
from .cases import detect_case
from ..intents import detect_intent
from ..core.text_norm import normalize_vi


# ====== Heuristic helpers ======

_TOOL_HINTS = (
    "tool", "dao", "mui khoan", "khoan", "phay", "taro", "doa", "tien",
    "endmill", "drill", "tap", "ream", "insert",
)

_HOLDER_HINTS = (
    "holder", "do ga", "bầu kẹp", "bau kep", "collet", "er", "bt", "hsk",
    "cat", "sk", "shank", "chuck", "bap kep",
)

_SEARCH_HINTS = (
    "tim", "tìm", "tra", "trả", "tra cuu", "tra cứu", "lookup",
    "ma", "mã", "code", "chi tiet", "chi tiết", "ton kho", "tồn kho",
    "o dau", "ở đâu", "vi tri", "vị trí",
)

_FUZZY_HINTS = (
    "de xuat", "đề xuất", "goi y", "gợi ý", "chon", "chọn", "phu hop", "phù hợp",
    "toi uu", "tối ưu", "fuzzy", "khuyen nghi", "khuyến nghị",
)

# mã tool/holder thường có dấu gạch nối
_CODE_RE = re.compile(r"\b[a-z0-9]{2,}(?:[-_][a-z0-9]{2,}){1,}\b", re.I)


def _guess_domain(text: str) -> Optional[str]:
    t = normalize_vi(text)

    # ưu tiên keyword rõ
    if any(k in t for k in _HOLDER_HINTS):
        return "holder"
    if any(k in t for k in _TOOL_HINTS):
        return "tool"

    # fallback theo pattern mã: (tuỳ bạn có quy ước H-xxx cho holder không)
    # nếu có "h-" thì nghiêng holder
    if "h-" in t or "holder" in t:
        return "holder"

    return None


def _guess_action(text: str) -> Optional[str]:
    t = normalize_vi(text)
    if any(k in t for k in _FUZZY_HINTS):
        return "fuzzy_suggest"
    if any(k in t for k in _SEARCH_HINTS):
        return "search_device"
    return None


def _extract_code(text: str) -> Optional[str]:
    m = _CODE_RE.search(text or "")
    if not m:
        return None
    return m.group(0).strip()


def route(user_message: str, state: SessionState, model: Optional[str] = None) -> RouteResult:
    """
    AI-first router:
    1) CASE deterministic (reset/cancel/yes-no/select/...)
    2) Heuristic intent/domain (rẻ + chắc) -> giảm menu
    3) LLM detect_intent khi heuristic không đủ
    """
    msg = (user_message or "").strip()

    # 1) cases
    c = detect_case(msg, state)
    if c:
        return c

    # 2) heuristic: đoán domain/action
    dom = _guess_domain(msg)
    action = _guess_action(msg)
    code = _extract_code(msg)

    # Nếu state đã có domain từ trước thì ưu tiên bám domain đó
    dom = state.get("domain") or dom

    # 2a) Nếu có action rõ ràng -> trả intent luôn
    if action in ("search_device", "fuzzy_suggest"):
        payload = {}
        if dom:
            payload["domain"] = dom
        if code:
            payload["code"] = code
        return {
            "kind": "intent",
            "type": action,
            "confidence": 0.86,   # heuristic tin cậy
            "reason": f"heuristic:{action}",
            "payload": payload,
        }

    # 2b) Nếu có domain rõ ràng + có code -> gần như chắc là search
    if dom and code:
        return {
            "kind": "intent",
            "type": "search_device",
            "confidence": 0.84,
            "reason": "heuristic:domain+code",
            "payload": {"domain": dom, "code": code},
        }

    # 3) intents (LLM)
    intent, conf, reason = detect_intent(msg, model=model)

    payload = {}
    if dom:
        payload["domain"] = dom
    if code:
        payload["code"] = code

    return {
        "kind": "intent",
        "type": intent,
        "confidence": conf,
        "reason": reason,
        "payload": payload,
    }

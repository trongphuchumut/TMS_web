# chatbot_v2/routing/cases.py
from __future__ import annotations

import re
from typing import Any, Dict, Optional

from ..core.text_norm import normalize_vi, parse_yes_no_short, is_why_question
from ..contracts.types import SessionState, RouteResult


# ===== patterns =====
RESET_RE = re.compile(r"\b(reset|lam lai|bat dau lai|xoa phien|clear)\b", re.I)
CANCEL_RE = re.compile(r"\b(huy|dung|stop|cancel|thoi)\b", re.I)

SELECT_IDX_RE = re.compile(r"\b(chon|lay|pick)\s*(cai|muc)?\s*(\d{1,2})\b", re.I)

# mã thiết bị (bạn có thể mở rộng theo format DB)
TOOL_CODE_RE = re.compile(r"\b(T\d{2,6}|DRL-[A-Za-z0-9\-_\.]+|TOOL-[A-Za-z0-9\-_\.]+)\b", re.I)
HOLDER_CODE_RE = re.compile(r"\b(H\d{2,6}|H-[A-Za-z0-9\-_\.]+|HOLDER-[A-Za-z0-9\-_\.]+)\b", re.I)


def _extract_slots_quick(text: str) -> Dict[str, Any]:
    """
    Slot parser nhẹ để nhận biết 'ADD_INFO' (bổ sung tiêu chí).
    Chỉ bắt vài thứ phổ biến, không dùng AI ở đây.
    """
    out: Dict[str, Any] = {}
    s = text or ""

    # Ø/phi/dk: 10mm
    m = re.search(r"(?:ø|\bphi\b|\bdk\b|diameter)\s*[:=]?\s*(\d+(?:\.\d+)?)\s*mm?\b", s, re.I)
    if m:
        out["diameter_mm"] = float(m.group(1))

    # Ra 1.6
    m = re.search(r"\bra\s*[:=]?\s*(\d+(?:\.\d+)?)\b", s, re.I)
    if m:
        out["roughness_ra"] = float(m.group(1))

    # tolerance ±0.01
    m = re.search(r"±\s*(\d+(?:\.\d+)?)", s)
    if m:
        out["tolerance_pm"] = float(m.group(1))

    # operation keywords
    if re.search(r"\b(phay|milling)\b", s, re.I):
        out["operation"] = "milling"
    if re.search(r"\b(tien|turning)\b", s, re.I):
        out["operation"] = "turning"
    if re.search(r"\b(khoan|drilling)\b", s, re.I):
        out["operation"] = "drilling"

    # ưu tiên nhanh
    sn = normalize_vi(s)
    if "uu tien" in sn and "do ben" in sn:
        out["priority"] = "durability"
    if "uu tien" in sn and "toc do" in sn:
        out["priority"] = "speed"
    if "uu tien" in sn and "gia" in sn:
        out["priority"] = "cost"

    return out


def detect_case(user_message: str, state: SessionState) -> Optional[RouteResult]:
    """
    Case-first router:
    - bắt chắc: reset/cancel/confirm/select/add_info/ask_explain
    - tránh gọi LLM cho các thứ deterministic
    """
    msg = (user_message or "").strip()
    t = normalize_vi(msg)

    # 1) reset / cancel
    if RESET_RE.search(t):
        return {"kind": "case", "type": "RESET", "confidence": 0.99, "reason": "rule_reset", "payload": {}}
    if CANCEL_RE.search(t):
        return {"kind": "case", "type": "CANCEL", "confidence": 0.99, "reason": "rule_cancel", "payload": {}}

    # 2) ask explain (vì sao/tại sao...)
    if is_why_question(msg):
        return {"kind": "case", "type": "ASK_EXPLAIN", "confidence": 0.9, "reason": "rule_why", "payload": {}}

    # 3) yes/no chỉ hợp lệ nếu đang có pending (hoặc đang confirm search)
    yn = parse_yes_no_short(msg)
    if yn:
        pending_qid = state.get("pending_question_id")
        search_confirm = state.get("search_confirm")

        if pending_qid or search_confirm:
            return {
                "kind": "case",
                "type": "CONFIRM_YES" if yn == "yes" else "CONFIRM_NO",
                "confidence": 0.95,
                "reason": "rule_confirm",
                "payload": {"question_id": pending_qid, "fields": state.get("pending_fields") or []},
            }

        # user nói ok/không nhưng không có cái gì đang chờ -> ambiguous confirm (chặn loop)
        return {"kind": "case", "type": "AMBIGUOUS_CONFIRM", "confidence": 0.7, "reason": "rule_ok_no_pending", "payload": {}}

    # 4) select candidate
    m = SELECT_IDX_RE.search(t)
    if m:
        return {
            "kind": "case",
            "type": "SELECT",
            "confidence": 0.92,
            "reason": "rule_select_index",
            "payload": {"by": "index", "index": int(m.group(3))},
        }

    mt = TOOL_CODE_RE.search(msg)
    if mt:
        return {
            "kind": "case",
            "type": "SELECT",
            "confidence": 0.9,
            "reason": "rule_select_tool_code",
            "payload": {"by": "tool_code", "code": mt.group(1)},
        }

    mh = HOLDER_CODE_RE.search(msg)
    if mh:
        return {
            "kind": "case",
            "type": "SELECT",
            "confidence": 0.9,
            "reason": "rule_select_holder_code",
            "payload": {"by": "holder_code", "code": mh.group(1)},
        }

    # 5) add_info (bổ sung tiêu chí)
    slots = _extract_slots_quick(msg)
    if slots:
        return {"kind": "case", "type": "ADD_INFO", "confidence": 0.82, "reason": "rule_slots", "payload": {"slots": slots}}

    return None

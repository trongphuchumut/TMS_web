# chatbot_v2/routing/intent_llm.py
from __future__ import annotations

from typing import Tuple, Optional

# reuse intent detector v1 để giảm rủi ro
from chatbot.intents import detect_intent as legacy_detect_intent


def detect_intent_llm(user_message: str, model: Optional[str] = None) -> Tuple[str, float, str]:
    """
    Coarse intent khi case detector không bắt được.
    Vẫn hỗ trợ switch model từ UI.
    """
    intent, conf, reason = legacy_detect_intent(user_message, model=model)

    # normalize output
    if intent not in ("smalltalk_faq", "search_device", "fuzzy_suggest", "clarify"):
        return "clarify", 0.4, "intent_invalid"

    conf = 0.0 if conf < 0 else (1.0 if conf > 1 else conf)
    return intent, conf, reason

# chatbot_v2/integrations/db.py
from __future__ import annotations

from typing import Any, Optional

from tool.models import Tool
from holder.models import Holder


def find_tool_by_code(code: str) -> Optional[Tool]:
    if not code:
        return None
    return Tool.objects.filter(ma_tool__iexact=code.strip()).first()


def find_holder_by_code(code: str) -> Optional[Holder]:
    if not code:
        return None
    return Holder.objects.filter(ma_noi_bo__iexact=code.strip()).first()


def device_label(obj: Any) -> str:
    return getattr(obj, "ten_tool", None) or getattr(obj, "ten_thiet_bi", None) or str(obj)

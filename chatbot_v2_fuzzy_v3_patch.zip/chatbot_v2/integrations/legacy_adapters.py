# chatbot_v2/integrations/legacy_adapters.py
from __future__ import annotations

import json
from typing import Any, Dict, Tuple, Optional

from chatbot.handlers_search import (
    handle_search_device as legacy_search_device,
    handle_search_confirm as legacy_search_confirm,
)

from chatbot.fuzzy.pipeline import run_fuzzy_suggest as legacy_run_fuzzy_suggest
from chatbot.fuzzy.criteria_parser import call_ai_for_criteria
from chatbot.fuzzy.dialog import is_exit_message, merge_criteria


# ===================== SEARCH =====================

def search_device(request, user_message: str) -> str:
    return legacy_search_device(request, user_message)


def search_confirm(request, user_message: str, state: Dict[str, Any], yes: bool) -> Tuple[str, bool]:
    intent = "confirm_yes" if yes else "confirm_no"
    return legacy_search_confirm(request=request, user_message=user_message, state=state, intent=intent)


# ===================== FUZZY =====================

def fuzzy_start(user_message: str, debug: bool = False, model: Optional[str] = None) -> Dict[str, Any]:
    return legacy_run_fuzzy_suggest(user_message, debug=debug, model=model)


def fuzzy_followup_with_model(
    user_message: str,
    fuzzy_state: Dict[str, Any],
    debug: bool = False,
    model: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Bản follow-up giống legacy dialog.handle_fuzzy_followup,
    nhưng bổ sung model cho call_ai_for_criteria và run_fuzzy_suggest.
    """
    if is_exit_message(user_message):
        return {
            "status": "exit",
            "message": "Ok, mình tạm dừng phần FUZZY. Khi cần bạn mô tả lại yêu cầu gia công, mình tư vấn từ đầu nhé.",
            "criteria": fuzzy_state.get("criteria"),
            "meta": {"exit": True},
        }

    old = fuzzy_state.get("criteria") or {}

    # Parse tiêu chí từ câu trả lời follow-up (✅ có model)
    new_criteria, raw, err = call_ai_for_criteria(user_message, model=model)

    if debug:
        print("[FUZZY_FOLLOWUP_V2] old:", old)
        print("[FUZZY_FOLLOWUP_V2] raw:", (raw or "")[:300])
        print("[FUZZY_FOLLOWUP_V2] err:", err)

    turns_left = int(fuzzy_state.get("turns_left") or 0)

    if (not new_criteria) or err:
        return {
            "status": "need_more_info",
            "message": (
                "Mình chưa bắt được ý bạn ở phần bổ sung. Bạn trả lời ngắn theo mẫu giúp mình:\n"
                "- Vật liệu: ...\n- Gia công: ...\n- ĐK (nếu có): ..."
            ),
            "criteria": old,
            "meta": {"turns_left": turns_left, "parse_error": str(err) if err else None},
        }

    merged = merge_criteria(old, new_criteria)

    # Chạy lại fuzzy với criteria merged: trick bằng cách đưa JSON criteria
    result = legacy_run_fuzzy_suggest(json.dumps(merged, ensure_ascii=False), debug=debug, model=model)
    result["criteria"] = merged
    return result

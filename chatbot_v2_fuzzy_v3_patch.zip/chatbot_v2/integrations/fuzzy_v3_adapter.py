# chatbot_v2/integrations/fuzzy_v3_adapter.py
from __future__ import annotations

from typing import Any, Dict, List, Optional

from ..fuzzy_v3.llm_parser import parse_fuzzy_inputs, build_inputs
from ..fuzzy_v3.engine import score_candidates
from ..integrations.ai import call_ai

# Prompt để AI "nói chuyện" dựa trên JSON kết quả (explain layer)
FUZZY_EXPLAIN_PROMPT = r"""
Bạn là trợ lý đề xuất sản phẩm (TMS) nói chuyện tự nhiên, ngắn gọn, đúng trọng tâm.

Bạn sẽ nhận:
1) USER_MESSAGE: lời người dùng
2) FUZZY_JSON: kết quả tính toán fuzzy (deterministic)
3) TOP_ITEMS: danh sách item đã chấm điểm (đã sort)

YÊU CẦU
- Không bịa thông tin không có trong JSON.
- Giải thích theo ngôn ngữ người dùng, có nhắc lại tiêu chí họ vừa nói (giá/độ bền/chính xác/tốc độ).
- Nếu thiếu thông tin (status=need_more_info) thì hỏi đúng câu hỏi trong FUZZY_JSON.clarifying_question (nếu có),
  hoặc hỏi 1 câu ngắn để lấp các missing_fields.
- Nếu có TOP_ITEMS: đề xuất 3 lựa chọn đầu tiên, nêu lý do ngắn (1 dòng mỗi lựa chọn).
- Nếu confidence thấp (<0.45), nói rõ "mình hiểu có thể chưa đúng" và hỏi xác nhận 1 điểm quan trọng nhất.
- Kết thúc bằng 1 câu hỏi gợi mở để tiếp tục hội thoại (VD: "Bạn ưu tiên rẻ hơn hay bền hơn?").

LUÔN TRẢ VỀ: 1 đoạn text (không JSON).
"""

def _default_candidates(domain: str) -> List[Dict[str, Any]]:
    """
    Fallback candidates khi chưa nối DB.
    Bạn nên thay bằng query Tool/Holder trong project thật.
    """
    if domain == "holder":
        return [
            {"id":"H-001", "name":"Holder phổ thông", "price_level":3, "durability_level":6, "precision_level":6, "speed_level":5},
            {"id":"H-002", "name":"Holder chính xác cao", "price_level":7, "durability_level":7, "precision_level":9, "speed_level":6},
            {"id":"H-003", "name":"Holder tốc độ cao", "price_level":6, "durability_level":6, "precision_level":7, "speed_level":9},
        ]
    return [
        {"id":"T-101", "name":"Dao carbide phổ thông", "price_level":4, "durability_level":7, "precision_level":6, "speed_level":6},
        {"id":"T-102", "name":"Dao phủ TiAlN bền", "price_level":6, "durability_level":9, "precision_level":7, "speed_level":6},
        {"id":"T-103", "name":"Dao micro chính xác", "price_level":7, "durability_level":6, "precision_level":9, "speed_level":5},
        {"id":"T-104", "name":"Dao tốc độ cao", "price_level":6, "durability_level":6, "precision_level":6, "speed_level":9},
    ]

def fuzzy_v3_start(
    user_message: str,
    *,
    model: Optional[str]=None,
    domain_hint: Optional[str]=None,
    prior_inputs: Optional[Dict[str, Any]]=None,
    candidates: Optional[List[Dict[str, Any]]]=None,
) -> Dict[str, Any]:
    """
    1) LLM parse -> fuzzy inputs (0..10)
    2) deterministic scoring -> TOP_ITEMS + fuzzy_json
    3) return json for UI / next explain step
    """
    parsed = parse_fuzzy_inputs(user_message, model=model, prior=prior_inputs)
    domain = domain_hint or parsed.get("domain") or "unknown"
    if domain == "unknown":
        domain = domain_hint or "tool"

    fin = parsed.get("inputs") or {}
    status = parsed.get("status") or "need_more_info"

    top_items: List[Dict[str, Any]] = []
    if status == "ok":
        inputs_obj = build_inputs(fin)
        cand = candidates or _default_candidates(domain)
        top_items = score_candidates(inputs_obj, cand)[:10]

    fuzzy_json = {
        "status": status,
        "domain": domain,
        "inputs": fin,
        "missing_fields": parsed.get("missing_fields") or [],
        "clarifying_question": parsed.get("clarifying_question"),
        "confidence": parsed.get("confidence"),
        "top_items": [
            {
                "id": it.get("id"),
                "name": it.get("name"),
                "score": it.get("_fuzzy", {}).get("score"),
                "membership": it.get("_fuzzy", {}).get("membership"),
            }
            for it in (top_items[:5] if top_items else [])
        ],
    }

    return {
        "status": status,
        "fuzzy_json": fuzzy_json,
        "top_items_full": top_items,  # for debug
        "raw_llm": parsed.get("raw"),
    }

def fuzzy_v3_explain(
    user_message: str,
    fuzzy_json: Dict[str, Any],
    top_items_full: Optional[List[Dict[str, Any]]]=None,
    *,
    model: Optional[str]=None,
) -> str:
    prompt = (
        FUZZY_EXPLAIN_PROMPT
        + "\n\nUSER_MESSAGE:\n" + user_message
        + "\n\nFUZZY_JSON:\n" + __import__("json").dumps(fuzzy_json, ensure_ascii=False)
        + "\n\nTOP_ITEMS:\n" + __import__("json").dumps((top_items_full or [])[:5], ensure_ascii=False)
    )
    return call_ai(prompt, model=model)

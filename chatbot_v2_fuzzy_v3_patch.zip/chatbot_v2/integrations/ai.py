# chatbot_v2/integrations/ai.py
from __future__ import annotations

from typing import Optional
from chatbot.ai_client import call_ai as legacy_call_ai


def call_ai(prompt: str, model: Optional[str] = None) -> str:
    m = (model or "").strip() or None
    return legacy_call_ai(prompt, model=m)

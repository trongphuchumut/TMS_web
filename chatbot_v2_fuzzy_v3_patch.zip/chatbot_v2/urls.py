# chatbot_v2/urls.py
from django.urls import path, re_path
from .views import chatbot_view_v2, fuzzy_last_page_v2

urlpatterns = [
    # UI fetch("/chatbot/", POST)
    path("", chatbot_view_v2, name="chatbot_v2"),

    # UI window.open("/chatbot/fuzzy/last/")
    path("fuzzy/last/", fuzzy_last_page_v2, name="fuzzy_last_v2"),
]

# Nếu bạn muốn "tắt các thứ xung quanh" (mọi route khác dưới /chatbot/ -> 410)
# thì bật đoạn dưới (và thêm view disabled_endpoint trong views.py)
#
# from .views import disabled_endpoint
# urlpatterns += [
#     re_path(r"^(?P<any_path>.*)$", disabled_endpoint, name="chatbot_v2_disabled"),
# ]

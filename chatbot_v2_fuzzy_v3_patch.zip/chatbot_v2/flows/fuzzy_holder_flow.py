# chatbot_v2/flows/fuzzy_holder_flow.py
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from holder.models import Holder

def _holder_candidates(limit: int = 50):
    try:
        qs = Holder.objects.all()[:limit]
        out = []
        for h in qs:
            out.append({
                "id": getattr(h, "id", None) or getattr(h, "pk", None) or getattr(h, "ma_holder", None),
                "name": getattr(h, "ten_holder", None) or str(h),
                "code": getattr(h, "ma_holder", None) or getattr(h, "ma_noi_bo", None) or "",
                "price": getattr(h, "gia", None) or getattr(h, "price", None) or getattr(h, "don_gia", None),
                "durability_level": getattr(h, "do_ben", None) or getattr(h, "durability", None),
                "precision_level": getattr(h, "do_chinh_xac", None) or getattr(h, "precision", None),
                "speed_level": getattr(h, "toc_do", None) or getattr(h, "speed", None),
            })
        return out
    except Exception:
        return None



from ..contracts.constants import FUZZY_TTL_TURNS
from ..contracts.types import SessionState
from ..core.session_store import set_last_fuzzy
from ..integrations.fuzzy_v3_adapter import fuzzy_v3_start, fuzzy_v3_explain

MIN_DURABILITY = 30  # chỉnh tuỳ bạn


def _holder_eligible(h: Holder) -> tuple[bool, str]:
    if h.trang_thai_tai_san != "san_sang":
        try:
            st = h.get_trang_thai_tai_san_display()
        except Exception:
            st = str(h.trang_thai_tai_san)
        return (False, f"Trạng thái: {st}")

    if h.mon is not None:
        try:
            v = int(h.mon)
        except Exception:
            v = None
        if v is not None and v < MIN_DURABILITY:
            return (False, f"Độ bền thấp ({v}%)")

    return (True, "")


def _filter_scored_holders(
    scored: List[Tuple[float, Any, Any]]
) -> tuple[List[Tuple[float, Holder, Any]], List[dict]]:
    ok: List[Tuple[float, Holder, Any]] = []
    rejected: List[dict] = []
    for s, dev, br in scored:
        if not isinstance(dev, Holder):
            continue
        eligible, reason = _holder_eligible(dev)
        if eligible:
            ok.append((s, dev, br))
        else:
            rejected.append(
                {
                    "code": dev.ma_noi_bo,
                    "name": dev.ten_thiet_bi,
                    "reason": reason,
                    "status": dev.trang_thai_tai_san,
                    "mon": dev.mon,
                }
            )
    ok.sort(key=lambda x: x[0], reverse=True)
    return ok, rejected


def _pack_last_fuzzy_holder(
    user_text: str,
    criteria: dict,
    scored_ok: List[Tuple[float, Holder, Any]],
    meta: dict,
) -> Dict[str, Any]:
    top = []
    for s, dev, br in scored_ok[:5]:
        top.append(
            {
                "score": round(float(s) * 100, 1),
                "name": dev.ten_thiet_bi,
                "code": dev.ma_noi_bo,
                "breakdown": br,
            }
        )

    plot = (meta.get("plot") or {}) if isinstance(meta, dict) else {}
    return {
        "ts": datetime.now().isoformat(),
        "question": user_text,
        "criteria": criteria or {},
        "top": top,
        "meta": {**(meta if isinstance(meta, dict) else {}), "plot": plot, "domain": "holder"},
    }


def start_fuzzy_holder(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    explain_fuzzy: bool = True,
    debug: bool = False,
) -> str:
    state.setdefault("fuzzy", {})
    fs = state["fuzzy"]
    prior_inputs = fs.get("inputs") or {}
    candidates = _holder_candidates()  # None -> adapter sẽ dùng fallback mẫu

    res = fuzzy_v3_start(
        user_message,
        model=model,
        domain_hint="holder",
        prior_inputs=prior_inputs,
        candidates=candidates,
    )
    status = res.get("status")
    fuzzy_json = res.get("fuzzy_json") or {}
    top_items_full = res.get("top_items_full") or []

    if status == "need_more_info":
        state["stage"] = "COLLECTING"
        fs["active"] = True
        fs["inputs"] = fuzzy_json.get("inputs") or prior_inputs
        fs["turns_left"] = int(fs.get("turns_left") or FUZZY_TTL_TURNS)
        state["fuzzy"] = fs
        state["domain"] = "holder"
        return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model) if explain_fuzzy else (fuzzy_json.get("clarifying_question") or "Bạn cho mình thêm thông tin nhé.")

    if status == "ok":
        fs["active"] = False
        fs["inputs"] = fuzzy_json.get("inputs") or {}
        state["fuzzy"] = fs
        state["stage"] = "PRESENTING"
        request.session.pop("fuzzy_state", None)

        # Lưu last_fuzzy cho UI
        from .fuzzy_flow import _pack_last_fuzzy  # reuse
        last = _pack_last_fuzzy(user_message, {
            "criteria": fuzzy_json.get("inputs") or {},
            "scored": top_items_full,
            "meta": {"engine":"fuzzy_v3", "confidence": fuzzy_json.get("confidence")},
        })
        set_last_fuzzy(request.session, state, last)

        return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model) if explain_fuzzy else "Mình đã chấm fuzzy xong."

    return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model) if explain_fuzzy else "Mình chưa xử lý được phần fuzzy."

def followup_fuzzy_holder(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    debug: bool = False,
) -> str:
    state.setdefault("fuzzy", {})
    fs = state["fuzzy"]
    prior_inputs = fs.get("inputs") or {}
    candidates = _holder_candidates()

    res = fuzzy_v3_start(
        user_message,
        model=model,
        domain_hint="holder",
        prior_inputs=prior_inputs,
        candidates=candidates,
    )
    status = res.get("status")
    fuzzy_json = res.get("fuzzy_json") or {}
    top_items_full = res.get("top_items_full") or []

    if status == "need_more_info":
        fs["active"] = True
        fs["inputs"] = fuzzy_json.get("inputs") or prior_inputs
        fs["turns_left"] = max(0, int(fs.get("turns_left") or FUZZY_TTL_TURNS) - 1)
        state["stage"] = "COLLECTING"
        state["fuzzy"] = fs
        return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model)

    if status == "ok":
        fs["active"] = False
        fs["inputs"] = fuzzy_json.get("inputs") or {}
        state["stage"] = "PRESENTING"
        state["fuzzy"] = fs

        from .fuzzy_flow import _pack_last_fuzzy
        last = _pack_last_fuzzy(user_message, {
            "criteria": fuzzy_json.get("inputs") or {},
            "scored": top_items_full,
            "meta": {"engine":"fuzzy_v3", "confidence": fuzzy_json.get("confidence")},
        })
        set_last_fuzzy(request.session, state, last)

        return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model)

    return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model)

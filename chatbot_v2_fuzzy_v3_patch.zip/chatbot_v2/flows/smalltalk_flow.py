# chatbot_v2/flows/smalltalk_flow.py
from __future__ import annotations

from typing import Any, Dict, List, Optional

# Reuse smalltalk handler v1 để giảm rủi ro import vòng
from chatbot.handlers_smalltalk import handle_smalltalk_faq as legacy_handle_smalltalk_faq


def handle_smalltalk(
    user_message: str,
    history: List[Dict[str, Any]],
    model: Optional[str] = None,
) -> str:
    """
    Wrapper smalltalk v2:
    - đảm bảo luôn có symbol handle_smalltalk để state_machine import/call
    - tránh circular import do faq_utils/call_ai trong giai đoạn đầu
    - model để sẵn (legacy có thể chưa dùng)
    """
    try:
        return legacy_handle_smalltalk_faq(user_message, history)
    except TypeError:
        return legacy_handle_smalltalk_faq(user_message, history, model=model)

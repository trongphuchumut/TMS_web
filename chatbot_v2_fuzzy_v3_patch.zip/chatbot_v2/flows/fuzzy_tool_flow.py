# chatbot_v2/flows/fuzzy_tool_flow.py
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from tool.models import Tool

def _tool_candidates(limit: int = 50):
    try:
        qs = Tool.objects.all()[:limit]
        out = []
        for t in qs:
            out.append({
                "id": getattr(t, "id", None) or getattr(t, "pk", None) or getattr(t, "ma_tool", None),
                "name": getattr(t, "ten_tool", None) or str(t),
                "code": getattr(t, "ma_tool", None) or getattr(t, "ma_noi_bo", None) or "",
                # Best-effort feature extraction; adjust in your project if bạn có field khác
                "price": getattr(t, "gia", None) or getattr(t, "price", None) or getattr(t, "don_gia", None),
                "durability_level": getattr(t, "do_ben", None) or getattr(t, "durability", None) or getattr(t, "wear_max", None),
                "precision_level": getattr(t, "do_chinh_xac", None) or getattr(t, "precision", None),
                "speed_level": getattr(t, "toc_do", None) or getattr(t, "speed", None) or getattr(t, "cv", None),
            })
        return out
    except Exception:
        return None



from ..contracts.constants import FUZZY_TTL_TURNS
from ..contracts.types import SessionState
from ..core.session_store import set_last_fuzzy
from ..integrations.fuzzy_v3_adapter import fuzzy_v3_start, fuzzy_v3_explain


def _tool_eligible(t: Tool) -> tuple[bool, str]:
    # Không đề xuất nếu không đủ tồn kho
    if (t.ton_kho or 0) <= 0:
        return (False, "Hết tồn kho")
    if t.muc_canh_bao is not None and t.ton_kho <= t.muc_canh_bao:
        return (False, f"Tồn kho thấp (≤ cảnh báo {t.muc_canh_bao})")
    return (True, "")


def _filter_scored_tools(
    scored: List[Tuple[float, Any, Any]]
) -> tuple[List[Tuple[float, Tool, Any]], List[dict]]:
    ok: List[Tuple[float, Tool, Any]] = []
    rejected: List[dict] = []
    for s, dev, br in scored:
        if not isinstance(dev, Tool):
            continue
        eligible, reason = _tool_eligible(dev)
        if eligible:
            ok.append((s, dev, br))
        else:
            rejected.append(
                {
                    "code": dev.ma_tool,
                    "name": dev.ten_tool,
                    "reason": reason,
                    "stock": dev.ton_kho,
                    "warn": dev.muc_canh_bao,
                }
            )
    ok.sort(key=lambda x: x[0], reverse=True)
    return ok, rejected


def _pack_last_fuzzy_tool(
    user_text: str,
    criteria: dict,
    scored_ok: List[Tuple[float, Tool, Any]],
    meta: dict,
) -> Dict[str, Any]:
    top = []
    for s, dev, br in scored_ok[:5]:
        top.append(
            {
                "score": round(float(s) * 100, 1),
                "name": dev.ten_tool,
                "code": dev.ma_tool,
                "breakdown": br,
            }
        )

    plot = (meta.get("plot") or {}) if isinstance(meta, dict) else {}
    return {
        "ts": datetime.now().isoformat(),
        "question": user_text,
        "criteria": criteria or {},
        "top": top,
        "meta": {**(meta if isinstance(meta, dict) else {}), "plot": plot, "domain": "tool"},
    }


def start_fuzzy_tool(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    explain_fuzzy: bool = True,
    debug: bool = False,
) -> str:
    state.setdefault("fuzzy", {})
    fs = state["fuzzy"]
    prior_inputs = fs.get("inputs") or {}
    candidates = _tool_candidates()  # None -> adapter sẽ dùng fallback mẫu

    res = fuzzy_v3_start(
        user_message,
        model=model,
        domain_hint="tool",
        prior_inputs=prior_inputs,
        candidates=candidates,
    )
    status = res.get("status")
    fuzzy_json = res.get("fuzzy_json") or {}
    top_items_full = res.get("top_items_full") or []

    if status == "need_more_info":
        state["stage"] = "COLLECTING"
        fs["active"] = True
        fs["inputs"] = fuzzy_json.get("inputs") or prior_inputs
        fs["turns_left"] = int(fs.get("turns_left") or FUZZY_TTL_TURNS)
        state["fuzzy"] = fs
        state["domain"] = "tool"
        return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model) if explain_fuzzy else (fuzzy_json.get("clarifying_question") or "Bạn cho mình thêm thông tin nhé.")

    if status == "ok":
        fs["active"] = False
        fs["inputs"] = fuzzy_json.get("inputs") or {}
        state["fuzzy"] = fs
        state["stage"] = "PRESENTING"
        request.session.pop("fuzzy_state", None)

        # Lưu last_fuzzy cho UI
        from .fuzzy_flow import _pack_last_fuzzy  # reuse
        last = _pack_last_fuzzy(user_message, {
            "criteria": fuzzy_json.get("inputs") or {},
            "scored": top_items_full,
            "meta": {"engine":"fuzzy_v3", "confidence": fuzzy_json.get("confidence")},
        })
        set_last_fuzzy(request.session, state, last)

        return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model) if explain_fuzzy else "Mình đã chấm fuzzy xong."

    return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model) if explain_fuzzy else "Mình chưa xử lý được phần fuzzy."

def followup_fuzzy_tool(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    debug: bool = False,
) -> str:
    state.setdefault("fuzzy", {})
    fs = state["fuzzy"]
    prior_inputs = fs.get("inputs") or {}
    candidates = _tool_candidates()

    res = fuzzy_v3_start(
        user_message,
        model=model,
        domain_hint="tool",
        prior_inputs=prior_inputs,
        candidates=candidates,
    )
    status = res.get("status")
    fuzzy_json = res.get("fuzzy_json") or {}
    top_items_full = res.get("top_items_full") or []

    if status == "need_more_info":
        fs["active"] = True
        fs["inputs"] = fuzzy_json.get("inputs") or prior_inputs
        fs["turns_left"] = max(0, int(fs.get("turns_left") or FUZZY_TTL_TURNS) - 1)
        state["stage"] = "COLLECTING"
        state["fuzzy"] = fs
        return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model)

    if status == "ok":
        fs["active"] = False
        fs["inputs"] = fuzzy_json.get("inputs") or {}
        state["stage"] = "PRESENTING"
        state["fuzzy"] = fs

        from .fuzzy_flow import _pack_last_fuzzy
        last = _pack_last_fuzzy(user_message, {
            "criteria": fuzzy_json.get("inputs") or {},
            "scored": top_items_full,
            "meta": {"engine":"fuzzy_v3", "confidence": fuzzy_json.get("confidence")},
        })
        set_last_fuzzy(request.session, state, last)

        return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model)

    return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model)

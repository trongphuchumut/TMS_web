# chatbot_v2/flows/search_tool_flow.py
from __future__ import annotations

from typing import Optional

from ..contracts.types import SessionState


def handle_search_tool(request, msg: str, state: SessionState) -> str:
    """
    Wrapper: search TOOL riêng.
    Tạm thời tái dùng search_flow cũ để không vỡ hệ thống.
    """
    # Ép domain cho chắc
    state["domain"] = "tool"  # type: ignore[assignment]

    # Nếu msg có prefix "tìm tool ..." thì bóc keyword
    raw = (msg or "").strip()
    low = raw.lower()
    for p in ("tim tool", "tìm tool", "tool"):
        if low.startswith(p):
            raw = raw[len(p):].strip(" :,-")
            break

    from ..flows.search_flow import handle_search
    return handle_search(request, raw, state)


def handle_search_tool_yesno(request, msg: str, state: SessionState, yes: bool) -> str:
    """
    Wrapper: confirm YES/NO cho TOOL.
    """
    state["domain"] = "tool"  # type: ignore[assignment]
    from ..flows.search_flow import handle_search_yesno
    return handle_search_yesno(request, msg, state, yes=yes)

# chatbot_v2/flows/search_flow.py
from __future__ import annotations

from typing import Any, Dict

from ..integrations.legacy_adapters import search_device, search_confirm
from ..contracts.types import SessionState


def handle_search(request, user_message: str, state: SessionState) -> str:
    """
    Legacy search có thể set request.session["device_confirm_state"].
    session_store sẽ sync vào state["search_confirm"] ở lượt sau.
    """
    reply = search_device(request, user_message)

    # sync ngay trong lượt hiện tại (cho mượt)
    sc = request.session.get("device_confirm_state")
    if isinstance(sc, dict):
        state["search_confirm"] = sc

    return reply


def handle_search_yesno(request, user_message: str, state: SessionState, yes: bool) -> str:
    sc = state.get("search_confirm")
    if not isinstance(sc, dict) or not sc:
        return (
            "Mình thấy bạn trả lời **đúng/không** nhưng hiện không có câu hỏi xác nhận nào đang chờ 🤔\n"
            "Bạn gửi lại **mã tool/holder** hoặc mô tả rõ hơn giúp mình nhé."
        )

    reply, done = search_confirm(request, user_message, sc, yes=yes)

    if done:
        state["search_confirm"] = None
        request.session.pop("device_confirm_state", None)
        request.session.modified = True

    return reply

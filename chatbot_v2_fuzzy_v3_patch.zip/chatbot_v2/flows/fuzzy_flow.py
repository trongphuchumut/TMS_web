# chatbot_v2/flows/fuzzy_flow.py
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional, Tuple

from ..integrations.fuzzy_v3_adapter import fuzzy_v3_start, fuzzy_v3_explain
from ..contracts.types import SessionState
from ..contracts.constants import FUZZY_TTL_TURNS
from ..core.session_store import set_last_fuzzy


def _pack_last_fuzzy(user_text: str, result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Chuẩn hoá last_fuzzy để template fuzzy_last.html dùng được.

    Hỗ trợ 2 dạng:
    - legacy: scored = [(score_0_1, device_obj, breakdown_dict), ...]
    - v3:     scored = [{"id","name","code","_fuzzy":{...}}, ...]
    """
    top = []

    scored = result.get("scored") or []
    # v3 dict style
    if scored and isinstance(scored[0], dict):
        for it in scored[:5]:
            fz = it.get("_fuzzy") or {}
            top.append({
                "score": float(fz.get("score") or 0.0),
                "name": it.get("name") or it.get("ten_tool") or it.get("ten_thiet_bi") or str(it.get("id") or ""),
                "code": it.get("code") or it.get("ma_tool") or it.get("ma_noi_bo") or it.get("id") or "",
                "breakdown": (fz.get("membership") or {}),
            })
    else:
        # legacy tuple style
        for s, dev, br in scored[:5]:
            name = getattr(dev, "ten_tool", None) or getattr(dev, "ten_thiet_bi", None) or str(dev)
            code = getattr(dev, "ma_tool", None) or getattr(dev, "ma_noi_bo", None) or ""
            top.append({
                "score": round(float(s) * 100, 1),
                "name": name,
                "code": code,
                "breakdown": br,
            })

    meta = result.get("meta") or {}
    plot = (meta.get("plot") or {}) if isinstance(meta, dict) else {}

    return {
        "ts": datetime.now().isoformat(),
        "question": user_text,
        "criteria": result.get("criteria") or {},
        "top": top,
        "meta": {
            **(meta if isinstance(meta, dict) else {}),
            "plot": plot,
        },
    }


def start_fuzzy(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    explain_fuzzy: bool = True,
    debug: bool = False,
) -> str:
    """
    V3: AI -> JSON (fuzzy inputs) -> fuzzy cứng -> JSON -> AI explain.
    """
    state.setdefault("fuzzy", {})
    fs = state["fuzzy"]

    prior_inputs = fs.get("inputs") or {}
    domain_hint = state.get("domain") or None

    res = fuzzy_v3_start(
        user_message,
        model=model,
        domain_hint=domain_hint,
        prior_inputs=prior_inputs,
    )

    status = res.get("status")
    fuzzy_json = res.get("fuzzy_json") or {}
    top_items_full = res.get("top_items_full") or []

    # Trạng thái hỏi thêm
    if status == "need_more_info":
        state["stage"] = "COLLECTING"
        fs["active"] = True
        fs["inputs"] = fuzzy_json.get("inputs") or prior_inputs
        fs["turns_left"] = int(fs.get("turns_left") or FUZZY_TTL_TURNS)
        state["fuzzy"] = fs

        # trả lời mượt: AI explain dựa trên JSON hỏi thiếu
        reply = fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model) if explain_fuzzy else (fuzzy_json.get("clarifying_question") or "Bạn cho mình thêm thông tin nhé.")
        return reply

    # OK -> chấm điểm và show
    if status == "ok":
        fs["active"] = False
        fs["inputs"] = fuzzy_json.get("inputs") or {}
        state["stage"] = "PRESENTING"
        state["fuzzy"] = fs

        # last_fuzzy cho UI (fuzzy_last.html)
        last = _pack_last_fuzzy(user_message, {
            "criteria": fuzzy_json.get("inputs") or {},
            "scored": top_items_full,
            "meta": {"engine": "fuzzy_v3", "confidence": fuzzy_json.get("confidence")},
        })
        set_last_fuzzy(request.session, state, last)

        reply = fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model) if explain_fuzzy else "Mình đã chấm fuzzy xong."
        return reply

    # fallback
    return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model) if explain_fuzzy else "Mình chưa xử lý được phần fuzzy."

def followup_fuzzy(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    debug: bool = False,
) -> str:
    """
    V3 followup: user bổ sung dần -> LLM merge -> khi đủ thì chấm lại.
    """
    state.setdefault("fuzzy", {})
    fs = state["fuzzy"]
    prior_inputs = fs.get("inputs") or {}
    domain_hint = state.get("domain") or None

    res = fuzzy_v3_start(
        user_message,
        model=model,
        domain_hint=domain_hint,
        prior_inputs=prior_inputs,
    )
    status = res.get("status")
    fuzzy_json = res.get("fuzzy_json") or {}
    top_items_full = res.get("top_items_full") or []

    if status == "need_more_info":
        fs["active"] = True
        fs["inputs"] = fuzzy_json.get("inputs") or prior_inputs
        fs["turns_left"] = max(0, int(fs.get("turns_left") or FUZZY_TTL_TURNS) - 1)
        state["stage"] = "COLLECTING"
        state["fuzzy"] = fs
        return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model)

    if status == "ok":
        fs["active"] = False
        fs["inputs"] = fuzzy_json.get("inputs") or {}
        state["stage"] = "PRESENTING"
        state["fuzzy"] = fs

        last = _pack_last_fuzzy(user_message, {
            "criteria": fuzzy_json.get("inputs") or {},
            "scored": top_items_full,
            "meta": {"engine": "fuzzy_v3", "confidence": fuzzy_json.get("confidence")},
        })
        set_last_fuzzy(request.session, state, last)
        return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model)

    return fuzzy_v3_explain(user_message, fuzzy_json, top_items_full, model=model)

# chatbot_v2/views.py
from __future__ import annotations
from datetime import datetime
import uuid

import json
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from .core.session_store import get_state, save_state, push_history
from .core.text_norm import to_bool
from .flows.state_machine import handle_message


@csrf_exempt
def chatbot_view_v2(request):
    if request.method != "POST":
        return JsonResponse({"reply": "Only POST"}, status=405)

    try:
        data = json.loads(request.body.decode("utf-8") or "{}")
    except Exception:
        return JsonResponse({"reply": "Body JSON không hợp lệ."}, status=400)

    user_message = (data.get("message") or "").strip()
    model = (data.get("model") or "gpt-oss:120b-cloud").strip()
    explain_fuzzy = to_bool(data.get("explain_fuzzy"), True)
    debug = to_bool(data.get("debug"), False)

    if not user_message:
        return JsonResponse({"reply": "Bạn nhập câu hỏi giúp mình nhé."})

    state = get_state(request.session)
    push_history(state, "user", user_message)
    
    # ===== DEBUG PRINT TERMINAL =====
    trace_id = uuid.uuid4().hex[:8]
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n[CHATBOT_V2][{trace_id}] {ts} | model={model} | explain={int(explain_fuzzy)} | debug={int(debug)}")
    print(f"[CHATBOT_V2][{trace_id}] USER: {user_message}")
    print(f"[CHATBOT_V2][{trace_id}] legacy device_confirm_state =", bool(request.session.get("device_confirm_state")))
    print(f"[CHATBOT_V2][{trace_id}] v2 state.search_confirm     =", bool(state.get("search_confirm")))

    res = handle_message(
        request,
        user_message,
        state,
        model=model,
        explain_fuzzy=explain_fuzzy,
        debug=debug,
    )

    reply = res.get("reply") or "Mình chưa xử lý được."

    print(f"[CHATBOT_V2][{trace_id}] BOT : {reply}")

    push_history(state, "bot", reply)
    save_state(request.session, state)

    return JsonResponse({"reply": reply})



def fuzzy_last_page_v2(request):
    last = request.session.get("last_fuzzy") or {}
    return render(request, "fuzzy_last.html", {"last": last, "last_json": last})

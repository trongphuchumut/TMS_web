# chatbot/views.py
import json
import unicodedata
from datetime import datetime

from django.http import JsonResponse, HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from .intents import detect_intent
from .handlers_smalltalk import handle_smalltalk_faq
from .handlers_search import handle_search_device
from .fuzzy.pipeline import run_fuzzy_suggest
from .fuzzy.dialog import handle_fuzzy_followup, FUZZY_TTL_TURNS

try:
    from .models import FuzzyRunLog
except Exception:
    FuzzyRunLog = None


def normalize_vi(text: str) -> str:
    """Lowercase + bỏ dấu tiếng Việt."""
    if not text:
        return ""
    text = text.lower().strip()
    text = unicodedata.normalize("NFD", text)
    return "".join(c for c in text if unicodedata.category(c) != "Mn")


def _is_why_question(text: str) -> bool:
    t = normalize_vi(text)
    keys = ["tai sao", "vi sao", "giai thich", "ly do", "why"]
    return any(k in t for k in keys)


def _format_last_fuzzy_explain(session) -> str | None:
    last = session.get("last_fuzzy")
    if not last:
        return None
    top = (last.get("top") or [])
    if not top:
        return None

    best = top[0]
    name = best.get("name")
    score = best.get("score")
    br = best.get("breakdown") or {}

    lines = []
    lines.append(f"🔎 **Vì sao chọn `{name}`?**")
    lines.append(f"- **Điểm fuzzy tổng:** {score}/100")
    if br:
        lines.append("- **Đóng góp theo tiêu chí (membership):**")
        for k, v in sorted(br.items(), key=lambda x: x[1], reverse=True):
            lines.append(f"  - {k}: {round(v*100)}%")
    lines.append("")
    lines.append("Nếu bạn muốn mình chấm lại chính xác hơn, bạn có thể bổ sung thêm: vật liệu, loại gia công, đường kính, chiều dài làm việc…")
    return "\n".join(lines)


def _store_last_fuzzy(request, user_text: str, result: dict):
    # Lưu session
    top = []
    for s, dev, br in (result.get("scored") or [])[:5]:
        top.append({
            "score": round(float(s) * 100, 1),
            "name": getattr(dev, "ten_tool", None) or getattr(dev, "ten_thiet_bi", None) or str(dev),
            "code": getattr(dev, "ma_tool", None) or getattr(dev, "ma_noi_bo", None) or "",
            "breakdown": br,
        })

    request.session["last_fuzzy"] = {
        "ts": datetime.now().isoformat(),
        "question": user_text,
        "criteria": result.get("criteria") or {},
        "top": top,
        "meta": result.get("meta") or {},
    }

    # Lưu DB log (nếu model có)
    if FuzzyRunLog:
        try:
            FuzzyRunLog.objects.create(
                user_text=user_text,
                criteria_json=request.session["last_fuzzy"]["criteria"],
                results_json=top,
            )
        except Exception:
            pass


def _ask_confirm(intent_guess: str) -> str:
    # confirm UI kiểu text (mobile-friendly)
    return (
        "Mình chưa chắc bạn muốn gì (độ chắc ~50-50). Bạn chọn giúp mình 1 ý nhé:\n"
        "1) **FUZZY đề xuất tool/holder**\n"
        "2) **Tìm kiếm thiết bị trong kho (theo mã/tên)**\n"
        "3) **Hỏi đáp/chào hỏi**\n"
        "👉 Trả lời: 1 / 2 / 3"
    )


def _parse_confirm_choice(text: str) -> str | None:
    t = normalize_vi(text)
    if t.strip() in ("1", "fuzzy", "de xuat", "goi y"):
        return "fuzzy_suggest"
    if t.strip() in ("2", "tim", "search"):
        return "search_device"
    if t.strip() in ("3", "chao", "hoi dap", "faq", "smalltalk"):
        return "smalltalk_faq"
    return None


@csrf_exempt
def chatbot_view(request):
    if request.method != "POST":
        return JsonResponse({"reply": "Only POST"}, status=405)

    data = json.loads(request.body or "{}")
    user_message = (data.get("message") or "").strip()
    model = (data.get("model") or "cloud").strip()  # "local" | "cloud"
    explain_fuzzy = bool(int(data.get("explain_fuzzy", 1)))  # 1/0 từ frontend

    if not user_message:
        return JsonResponse({"reply": "Bạn nhập câu hỏi giúp mình nhé."})

    debug = bool(data.get("debug", False))

    history = request.session.get("chat_history", [])
    history.append({"role": "user", "content": user_message})

    print("\n[CHATBOT] User:", user_message)
    print("[CHATBOT] History length:", len(history))

    # ===== A) PENDING CONFIRM MODE =====
    pending = request.session.get("pending_confirm")
    if pending:
        chosen = _parse_confirm_choice(user_message)
        if chosen:
            # dùng message gốc đã pending
            original = pending.get("original") or user_message
            request.session.pop("pending_confirm", None)
            user_message = original
        else:
            reply = "Bạn chỉ cần trả lời 1 / 2 / 3 nha 🙂"
            history.append({"role": "bot", "content": reply})
            request.session["chat_history"] = history
            return JsonResponse({"reply": reply})
        

    # ===== B) FUZZY FOLLOW-UP MODE (slot filling) =====
    fuzzy_state = request.session.get("fuzzy_state")
    if fuzzy_state:
        # TTL giảm dần để "làm mờ"
        fuzzy_state["turns_left"] = int(fuzzy_state.get("turns_left", FUZZY_TTL_TURNS))
        if fuzzy_state["turns_left"] <= 0:
            request.session.pop("fuzzy_state", None)
            fuzzy_state = None

    if fuzzy_state:
        print("[CHATBOT] Fuzzy follow-up mode ON. turns_left=", fuzzy_state.get("turns_left"))
        
        try:
            res = handle_fuzzy_followup(
                user_message,
                fuzzy_state,
                debug=debug,
                model=fuzzy_state.get("model") or model
            )
        except TypeError:
            res = handle_fuzzy_followup(user_message, fuzzy_state, debug=debug)

        if res.get("status") == "exit":
            request.session.pop("fuzzy_state", None)
        elif res.get("status") == "need_more_info":
            # update ttl
            fuzzy_state["turns_left"] = int(res.get("meta", {}).get("turns_left", fuzzy_state.get("turns_left", FUZZY_TTL_TURNS))) - 1
            fuzzy_state["criteria"] = res.get("criteria") or fuzzy_state.get("criteria")
            fuzzy_state["model"] = fuzzy_state.get("model") or model
            request.session["fuzzy_state"] = fuzzy_state
        elif res.get("status") == "ok":
            request.session.pop("fuzzy_state", None)
            _store_last_fuzzy(request, fuzzy_state.get("description") or user_message, res)

        reply = res.get("message") or "Mình chưa xử lý được phần FUZZY."
        history.append({"role": "bot", "content": reply})
        request.session["chat_history"] = history
        return JsonResponse({"reply": reply})

    # ===== C) WHY question (giải thích) =====
    if _is_why_question(user_message):
        explain = _format_last_fuzzy_explain(request.session)
        if explain:
            history.append({"role": "bot", "content": explain})
            request.session["chat_history"] = history
            return JsonResponse({"reply": explain})

    # ===== D) DETECT INTENT =====
    intent, conf, reason = detect_intent(user_message, model=model)

    print("[CHATBOT] intent:", intent, "conf:", conf, "reason:", reason)

    # Nếu confidence lưng chừng -> hỏi xác nhận (giảm hiểu nhầm)
    if 0.45 <= conf <= 0.65 and intent in ("fuzzy_suggest", "search_device", "smalltalk_faq"):
        request.session["pending_confirm"] = {"original": user_message, "guess": intent, "conf": conf}
        reply = _ask_confirm(intent)
        history.append({"role": "bot", "content": reply})
        request.session["chat_history"] = history
        return JsonResponse({"reply": reply})

    # ===== E) ROUTING =====
    if intent == "smalltalk_faq":
        reply = handle_smalltalk_faq(user_message, history)

    elif intent == "search_device":
        reply = handle_search_device(request, user_message)

    elif intent == "fuzzy_suggest":
        # truyền model xuống fuzzy pipeline (nếu pipeline của bạn hỗ trợ)
        try:
            result = run_fuzzy_suggest(user_message, debug=debug, model=model)
        except TypeError:
            # nếu hàm chưa nhận model thì vẫn chạy như cũ
            result = run_fuzzy_suggest(user_message, debug=debug)

        reply = result["message"]

        if result["status"] == "need_more_info":
            request.session["fuzzy_state"] = {
                "description": user_message,
                "criteria": result.get("criteria") or {},
                "turns_left": FUZZY_TTL_TURNS,
                "model": model,  # lưu để follow-up biết model đang dùng
            }
        elif result["status"] == "ok":
            _store_last_fuzzy(request, user_message, result)

            # nếu bật explain -> tự kèm “tại sao” ngắn (khỏi phải hỏi lại)
            if explain_fuzzy:
                exp = _format_last_fuzzy_explain(request.session)
                if exp:
                    reply = reply + "\n\n" + exp


        

    else:
        reply = "Mình chưa chắc ý bạn. Bạn có thể nói rõ hơn: bạn muốn **tìm thiết bị** hay **đề xuất theo fuzzy**?"

    history.append({"role": "bot", "content": reply})
    request.session["chat_history"] = history
    print("[CHATBOT] Reply:", reply[:150], "...\n")
    return JsonResponse({"reply": reply})




def fuzzy_last_page(request):
    """
    Trang demo khi bảo vệ: xem câu hỏi fuzzy gần nhất + biểu đồ.
    """
    last = request.session.get("last_fuzzy")
    return render(request, "fuzzy_last.html", {"last": last, "last_json": json.dumps(last or {}, ensure_ascii=False)})


def fuzzy_last_json(request):
    last = request.session.get("last_fuzzy") or {}
    return JsonResponse(last)

from django.urls import path
from chatbot.views import chatbot_view, fuzzy_last_page, fuzzy_last_json

urlpatterns = [
    path("api/chatbot/", chatbot_view, name="chatbot_api"),
    path("fuzzy/last/", fuzzy_last_page, name="fuzzy_last_page"),
    path("api/fuzzy/last/", fuzzy_last_json, name="fuzzy_last_json"),
]

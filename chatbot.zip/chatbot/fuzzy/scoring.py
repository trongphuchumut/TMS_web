# chatbot/fuzzy/scoring.py
"""
FUZZY SCORING CORE

Mục tiêu:
- Chấm điểm theo membership (tam giác / hình thang)
- Có "breakdown" để giải thích: mỗi tiêu chí đóng góp bao nhiêu
- Điểm cuối: 0..1

Lưu ý:
- Vì model Tool/Holder của bạn có thể khác nhau theo từng phiên bản,
  code dưới đây dùng getattr an toàn (không có field thì bỏ qua tiêu chí đó).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

import unicodedata
from difflib import SequenceMatcher


def normalize_vi(text: str) -> str:
    if not text:
        return ""
    text = str(text).lower().strip()
    text = unicodedata.normalize("NFD", text)
    return "".join(c for c in text if unicodedata.category(c) != "Mn")


def sim(a: str, b: str) -> float:
    a, b = normalize_vi(a), normalize_vi(b)
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def tri(x: float, a: float, b: float, c: float) -> float:
    """Membership tam giác."""
    if x <= a or x >= c:
        return 0.0
    if x == b:
        return 1.0
    if x < b:
        return (x - a) / (b - a) if (b - a) else 0.0
    return (c - x) / (c - b) if (c - b) else 0.0


def clamp01(v: float) -> float:
    return 0.0 if v < 0 else (1.0 if v > 1 else v)


def _prio_to_weight(prio: str | None) -> float:
    # cao -> weight lớn, thap -> nhỏ
    if not prio:
        return 1.0
    p = prio.lower()
    if p in ("cao", "high"):
        return 1.35
    if p in ("trung_binh", "trung binh", "medium"):
        return 1.0
    if p in ("thap", "low"):
        return 0.75
    return 1.0


def _get_float(obj: Any, attr: str) -> float | None:
    v = getattr(obj, attr, None)
    try:
        return float(v) if v is not None else None
    except Exception:
        return None


def _get_text(obj: Any, attr: str) -> str | None:
    v = getattr(obj, attr, None)
    if v is None:
        return None
    s = str(v).strip()
    return s or None


def _material_score(dev: Any, vat_lieu: str | None) -> float | None:
    if not vat_lieu:
        return None
    # Tool: vat_lieu_phu_hop; Holder: vat_lieu_phu_hop có thể không có
    candidates = [
        _get_text(dev, "vat_lieu_phu_hop"),
        _get_text(dev, "vat_lieu"),
        _get_text(dev, "nhom_vat_lieu"),
        _get_text(dev, "ghi_chu"),
    ]
    candidates = [c for c in candidates if c]
    if not candidates:
        return None
    best = max(sim(vat_lieu, c) for c in candidates)
    return clamp01(best)


def _process_score(dev: Any, loai_gia_cong: str | None) -> float | None:
    if not loai_gia_cong:
        return None
    candidates = [
        _get_text(dev, "loai_gia_cong"),
        _get_text(dev, "nhom_tool"),
        _get_text(dev, "dong_tool"),
        _get_text(dev, "nhom_thiet_bi"),
        _get_text(dev, "loai_holder"),
        _get_text(dev, "ten_tool"),
        _get_text(dev, "ten_thiet_bi"),
    ]
    candidates = [c for c in candidates if c]
    if not candidates:
        return None
    best = max(sim(loai_gia_cong, c) for c in candidates)
    # Cho tolerant hơn
    return clamp01(best)


def _diameter_score(dev: Any, req_d: float | None) -> float | None:
    if req_d is None:
        return None
    d = _get_float(dev, "duong_kinh")
    if d is None:
        return None
    # Triangular quanh req_d với biên 10% và 25%
    a = req_d * 0.75
    b = req_d
    c = req_d * 1.10
    # Nếu sai lệch lớn: rớt mạnh
    return clamp01(tri(d, a, b, c))


def _length_score(dev: Any, req_l: float | None) -> float | None:
    if req_l is None:
        return None
    l = _get_float(dev, "chieu_dai_lam_viec") or _get_float(dev, "chieu_dai")
    if l is None:
        return None
    a = req_l * 0.70
    b = req_l
    c = req_l * 1.20
    return clamp01(tri(l, a, b, c))


def score_device(dev: Any, criteria: dict) -> Tuple[float, Dict[str, float]]:
    """
    Trả về (score 0..1, breakdown)
    breakdown: điểm membership từng tiêu chí trước khi nhân trọng số.
    """
    uu = (criteria.get("uu_tien") or {}) if isinstance(criteria, dict) else {}

    parts: Dict[str, float] = {}
    weights: Dict[str, float] = {}

    # --- Material ---
    m = _material_score(dev, criteria.get("vat_lieu"))
    if m is not None:
        parts["vat_lieu"] = m
        weights["vat_lieu"] = 1.20

    # --- Process ---
    p = _process_score(dev, criteria.get("loai_gia_cong"))
    if p is not None:
        parts["loai_gia_cong"] = p
        weights["loai_gia_cong"] = 1.20 * _prio_to_weight(uu.get("toc_do"))

    # --- Diameter ---
    d = _diameter_score(dev, criteria.get("duong_kinh"))
    if d is not None:
        parts["duong_kinh"] = d
        weights["duong_kinh"] = 1.00 * _prio_to_weight(uu.get("do_chinh_xac"))

    # --- Length ---
    l = _length_score(dev, criteria.get("chieu_dai_lam_viec"))
    if l is not None:
        parts["chieu_dai_lam_viec"] = l
        weights["chieu_dai_lam_viec"] = 0.85 * _prio_to_weight(uu.get("chat_luong_be_mat"))

    # Nếu không có gì để chấm: score 0
    if not parts:
        return 0.0, {}

    # Weighted average
    num = sum(parts[k] * weights.get(k, 1.0) for k in parts)
    den = sum(weights.get(k, 1.0) for k in parts)
    score = (num / den) if den else 0.0
    return clamp01(score), parts


def score_all_candidates(candidates: List[Any], criteria: dict) -> List[Tuple[float, Any, Dict[str, float]]]:
    """
    Trả list [(score, dev, breakdown), ...] sort giảm dần.
    """
    scored = []
    for dev in candidates:
        s, br = score_device(dev, criteria)
        scored.append((s, dev, br))
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored

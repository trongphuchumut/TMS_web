# chatbot/fuzzy/candidates.py
from __future__ import annotations

from django.db.models import Q

from holder.models import Holder
from tool.models import Tool


def get_candidates(criteria: dict | None) -> tuple[list, str]:
    """
    Lấy candidates phục vụ FUZZY.
    - Ưu tiên lọc thô bằng DB để giảm nhiễu
    - Nếu thiếu info thì fallback lấy nhiều hơn (để vẫn có đáp án)
    """
    loai = "tool"
    if criteria:
        loai = (criteria.get("loai_thiet_bi") or "tool").lower().strip()

    vat_lieu = (criteria.get("vat_lieu") or "").strip() if criteria else ""
    loai_gia_cong = (criteria.get("loai_gia_cong") or "").strip() if criteria else ""

    def tool_qs():
        qs = Tool.objects.all()
        cond = Q()
        if vat_lieu:
            cond |= Q(vat_lieu_phu_hop__icontains=vat_lieu)
        if loai_gia_cong:
            cond |= Q(nhom_tool__icontains=loai_gia_cong) | Q(dong_tool__icontains=loai_gia_cong) | Q(ten_tool__icontains=loai_gia_cong)
        if cond:
            qs = qs.filter(cond)
        return qs

    def holder_qs():
        qs = Holder.objects.all()
        cond = Q()
        if loai_gia_cong:
            cond |= Q(nhom_thiet_bi__icontains=loai_gia_cong) | Q(loai_holder__icontains=loai_gia_cong) | Q(ten_thiet_bi__icontains=loai_gia_cong)
        if vat_lieu:
            cond |= Q(ghi_chu__icontains=vat_lieu) | Q(ten_thiet_bi__icontains=vat_lieu)
        if cond:
            qs = qs.filter(cond)
        return qs

    # Nếu user nói chung chung, đừng filter quá chặt
    broad = not vat_lieu and not loai_gia_cong

    if loai == "holder":
        qs = holder_qs()
        candidates = list(qs[:200 if broad else 120])
    elif loai == "both":
        candidates = list(holder_qs()[:80]) + list(tool_qs()[:120])
    else:
        qs = tool_qs()
        candidates = list(qs[:250 if broad else 160])

    return candidates, loai

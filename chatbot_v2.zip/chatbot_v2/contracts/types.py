# chatbot_v2/contracts/types.py
from __future__ import annotations
from typing import Any, Optional, TypedDict, List, Dict

from .constants import Role, Stage, RouteKind, CaseType, IntentType


class IncomingPayload(TypedDict, total=False):
    message: str
    model: str
    explain_fuzzy: int | bool
    debug: bool


class ChatMessage(TypedDict):
    role: Role
    content: str


class SearchConfirmState(TypedDict, total=False):
    # state do legacy search handler tạo ra (type/id/code/name...)
    type: str
    id: int
    code: str
    name: str


class FuzzyState(TypedDict, total=False):
    active: bool
    description: str
    criteria: Dict[str, Any]
    turns_left: int
    model: str


class SessionState(TypedDict, total=False):
    stage: Stage
    chat_history: List[ChatMessage]

    pending_question_id: Optional[str]
    pending_fields: List[str]
    pending_options: List[str]

    search_confirm: Optional[SearchConfirmState]
    fuzzy: FuzzyState

    last_fuzzy: Dict[str, Any]


class RouteResult(TypedDict, total=False):
    kind: RouteKind
    type: str  # CaseType | IntentType (giữ string để linh hoạt)
    confidence: float
    reason: str
    payload: Dict[str, Any]


class BotResponse(TypedDict, total=False):
    reply: str
    state: SessionState

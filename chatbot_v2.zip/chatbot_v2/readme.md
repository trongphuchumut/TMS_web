 # Chatbot V2 (TMS) – Architecture Reference

Mục tiêu của `chatbot_v2`:
- Giữ nguyên UI widget hiện tại (frontend vẫn gọi `POST /chatbot/` và mở `/chatbot/fuzzy/last/`).
- Thay thế logic chatbot cũ bằng kiến trúc rõ ràng: tách routing/case, flow/state machine, integrations, session store.
- Giảm rủi ro “AI tự nhận định chi phối quyết định”, tránh vòng lặp `ok/ừ`, và dễ mở rộng.

---

## 1) Endpoints (UI Contract)

UI widget đang dùng 2 endpoint này, **không được đổi**:

1. `POST /chatbot/`
   - Body JSON:
     ```json
     {
       "message": "string",
       "model": "gpt-oss:120b-cloud | gemma3:4b | ...",
       "explain_fuzzy": 0|1,
       "debug": true|false
     }
     ```
   - Response JSON:
     ```json
     { "reply": "string (HTML allowed for bot)" }
     ```

2. `GET /chatbot/fuzzy/last/`
   - Mở trang “fuzzy last” (tam giác fuzzy / thông tin lần gần nhất).

Optional (debug):
- `GET /chatbot/api/fuzzy/last/` -> trả JSON `last_fuzzy` trong session

> Tất cả các route khác dưới `/chatbot/...` nên bị disable (410) để tránh phụ thuộc vào legacy routes.

---

## 2) Design Principles (Quy tắc kiến trúc)

### P1. View mỏng
`views.py` chỉ làm:
- parse request
- lấy state từ session
- gọi core flow handler
- trả JsonResponse / render template

✅ Không viết if/else routing dài trong view.

### P2. Case-first, LLM-second
- `routing/cases.py`: bắt các trường hợp chắc chắn bằng rule + state (reset/cancel/confirm/select/add_info).
- `routing/intent_llm.py`: chỉ gọi LLM khi case detector không bắt được.
- `routing/router.py`: kết hợp 2 tầng trên.

### P3. Fuzzy chỉ ăn dữ liệu USER/CONFIRMED
- Giá trị “AI đoán” gắn nhãn INFERRED.
- INFERRED chỉ dùng để hỏi xác nhận, **không dùng để chấm fuzzy** nếu chưa confirm.

### P4. Mọi câu hỏi confirm phải có question_id
Để tránh vòng lặp “ok/ừ” không biết confirm cái gì, mọi prompt hỏi xác nhận phải set:
- `pending_question_id`
- `pending_fields`
- `pending_options` (nếu có lựa chọn)

### P5. Session state thống nhất
Chỉ lưu một object state chính: `chatbot_v2_state` (trong session).
Không rải session keys lung tung.

---

## 3) Directory Structure & Responsibilities

```text
chatbot_v2/
  urls.py                 # khai báo endpoints
  views.py                # controller mỏng (no business logic)

  README.md               # tài liệu tham chiếu (file này)

  contracts/
    types.py              # TypedDict/dataclass: payload/state/route/response
    constants.py          # keys session, TTL, threshold, enums

  core/
    session_store.py      # get_state/save_state, push_history, store_last_fuzzy
    text_norm.py          # normalize_vi, to_bool, parse_yes_no_short
    logging.py            # trace_id, debug logging helpers
    errors.py             # exception nội bộ có nghĩa

  routing/
    cases.py              # detect_case(message, state) -> CaseEvent
    intent_llm.py         # detect_intent_llm(message, model) -> coarse intent
    router.py             # route() = case-first, llm-second

  flows/
    state_machine.py      # dispatch theo stage + route_result
    search_flow.py        # tìm thiết bị + confirm
    fuzzy_flow.py         # fuzzy suggest + follow-up + explain
    smalltalk_flow.py     # chào hỏi/faq
    fallback_flow.py      # clarify / ambiguous confirm -> hỏi lại đúng cách

  integrations/
    legacy_adapters.py    # bọc code chatbot v1 (handlers_search/fuzzy pipeline/dialog)
    ai.py                 # wrapper call_ai đảm bảo switch model
    db.py                 # truy vấn DB nếu v2 cần

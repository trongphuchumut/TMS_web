# chatbot_v2/core/errors.py
from __future__ import annotations


class ChatbotV2Error(Exception):
    """Base error cho chatbot_v2."""


class BadPayload(ChatbotV2Error):
    """Payload JSON không hợp lệ hoặc thiếu field quan trọng."""


class FlowError(ChatbotV2Error):
    """Lỗi xử lý luồng (flow) do state không hợp lệ."""


class IntegrationError(ChatbotV2Error):
    """Lỗi khi gọi legacy/adapters/AI/DB."""

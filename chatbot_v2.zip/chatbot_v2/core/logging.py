# chatbot_v2/core/logging.py
from __future__ import annotations

import logging
import uuid
from typing import Any, Dict, Optional


def get_logger(name: str = "chatbot_v2") -> logging.Logger:
    return logging.getLogger(name)


def new_trace_id() -> str:
    return uuid.uuid4().hex[:10]


def log_event(
    logger: logging.Logger,
    event: str,
    trace_id: str,
    **data: Any,
) -> None:
    """
    Log 1 event theo format ổn định để debug loop/routing.
    """
    payload: Dict[str, Any] = {"event": event, "trace_id": trace_id}
    payload.update(data)
    logger.info(payload)

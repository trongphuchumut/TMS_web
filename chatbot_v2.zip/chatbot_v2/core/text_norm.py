# chatbot_v2/core/text_norm.py
from __future__ import annotations
import re
import unicodedata
from typing import Optional

def normalize_vi(text: str) -> str:
    if not text:
        return ""
    s = text.lower().strip()
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    s = re.sub(r"\s+", " ", s)
    return s

def to_bool(v, default: bool = False) -> bool:
    if isinstance(v, bool):
        return v
    if v is None:
        return default
    if isinstance(v, (int, float)):
        return bool(int(v))
    s = str(v).strip().lower()
    if s in ("1", "true", "yes", "y", "on", "ok", "oke", "okay"):
        return True
    if s in ("0", "false", "no", "n", "off"):
        return False
    return default

def parse_yes_no_short(text: str) -> Optional[str]:
    """
    Chỉ coi yes/no khi message ngắn để tránh match nhầm câu dài.
    """
    t = normalize_vi(text)
    if len(t) > 12:
        return None
    if t in ("dung", "yes", "y", "ok", "oke", "okay", "xac nhan", "dong y", "chuan", "duoc"):
        return "yes"
    if t in ("khong", "ko", "k", "no", "n", "sai", "khong dung", "chua"):
        return "no"
    return None

from typing import Optional
import re

def parse_yes_no_confirm(text: str) -> Optional[str]:
    """
    Dùng riêng cho bước CONFIRM (search_confirm).
    Bắt chắc 'đúng/không' kể cả có dấu câu, câu dài.
    """
    t = normalize_vi(text)
    if not t:
        return None

    # remove punctuation / ký tự lạ
    t = re.sub(r"[^a-z0-9 ]+", " ", t)
    t = re.sub(r"\s+", " ", t).strip()

    # phím tắt
    if t == "1":
        return "yes"
    if t == "2":
        return "no"

    # match exact
    if t in ("dung", "dung roi", "dung nha", "chuan", "ok", "oke", "okay", "yes", "y", "dong y", "xac nhan"):
        return "yes"
    if t in ("khong", "khong dung", "ko", "k", "no", "n", "sai", "chua"):
        return "no"

    # match contains (cho câu dài)
    if re.search(r"\b(dung|chuan|dong y|xac nhan|ok|oke|okay|yes)\b", t):
        return "yes"
    if re.search(r"\b(khong|ko|sai|no)\b", t):
        return "no"

    return None


def is_why_question(text: str) -> bool:
    t = normalize_vi(text)
    return any(k in t for k in ("tai sao", "vi sao", "giai thich", "ly do", "why"))

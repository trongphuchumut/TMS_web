# chatbot_v2/core/session_store.py
from __future__ import annotations

from typing import Any, Dict, List

from ..contracts.constants import SESSION_KEY, MAX_HISTORY, FUZZY_TTL_TURNS
from ..contracts.types import SessionState, ChatMessage


def default_state() -> SessionState:
    return {
        "stage": "IDLE",
        "domain": None,  # ✅ rất quan trọng để không hỏi Tool/Holder lại hoài
        "chat_history": [],
        "pending_question_id": None,
        "pending_fields": [],
        "pending_options": [],
        "search_confirm": None,
        "fuzzy": {
            "active": False,
            "description": "",
            "criteria": {},
            "turns_left": FUZZY_TTL_TURNS,
            "model": "",
        },
        "last_fuzzy": {},
    }


def _ensure_base_keys(raw: dict) -> dict:
    base = default_state()
    for k, v in base.items():
        if k not in raw:
            raw[k] = v

    # ensure fuzzy keys
    if not isinstance(raw.get("fuzzy"), dict):
        raw["fuzzy"] = {}
    fbase = base["fuzzy"]
    for k, v in fbase.items():
        if k not in raw["fuzzy"]:
            raw["fuzzy"][k] = v

    # ensure types
    if not isinstance(raw.get("chat_history"), list):
        raw["chat_history"] = []
    if not isinstance(raw.get("pending_fields"), list):
        raw["pending_fields"] = []
    if not isinstance(raw.get("pending_options"), list):
        raw["pending_options"] = []

    return raw


def _trim_history(raw: dict) -> None:
    hist = raw.get("chat_history") or []
    if not isinstance(hist, list):
        hist = []
    if len(hist) > MAX_HISTORY:
        hist = hist[-MAX_HISTORY:]
    raw["chat_history"] = hist


def get_state(session) -> SessionState:
    raw = session.get(SESSION_KEY)
    if not isinstance(raw, dict):
        raw = {}

    raw = _ensure_base_keys(raw)
    _trim_history(raw)

    # ✅ Sync legacy search confirm <-> v2
    legacy_sc = session.get("device_confirm_state")
    sc2 = raw.get("search_confirm")

    if isinstance(legacy_sc, dict) and legacy_sc:
        raw["search_confirm"] = legacy_sc
    elif isinstance(sc2, dict) and sc2:
        session["device_confirm_state"] = sc2

    # ✅ Sync last_fuzzy <-> session['last_fuzzy'] (để template cũ vẫn dùng được)
    legacy_last = session.get("last_fuzzy")
    lf2 = raw.get("last_fuzzy")

    if isinstance(legacy_last, dict) and legacy_last:
        raw["last_fuzzy"] = legacy_last
    elif isinstance(lf2, dict) and lf2:
        session["last_fuzzy"] = lf2

    session[SESSION_KEY] = raw
    session.modified = True
    return raw  # type: ignore[return-value]


def save_state(session, state: SessionState) -> None:
    session[SESSION_KEY] = state
    session.modified = True


def push_history(state: SessionState, role: str, content: str) -> None:
    hist: List[ChatMessage] = state.get("chat_history") or []
    if not isinstance(hist, list):
        hist = []
    hist.append({"role": role, "content": content})
    if len(hist) > MAX_HISTORY:
        hist = hist[-MAX_HISTORY:]
    state["chat_history"] = hist


def set_last_fuzzy(session, state: SessionState, last_fuzzy: Dict[str, Any]) -> None:
    """
    Lưu last_fuzzy vào v2 state.
    Đồng thời mirror sang session['last_fuzzy'] để template fuzzy_last.html cũ vẫn dùng được.
    """
    state["last_fuzzy"] = last_fuzzy
    session["last_fuzzy"] = last_fuzzy
    save_state(session, state)

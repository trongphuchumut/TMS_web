# chatbot_v2/intents.py
from __future__ import annotations

import json
import re
from typing import Tuple, Optional

from chatbot.ai_client import call_ai


INTENT_SYSTEM = """
Bạn là bộ phân loại ý định cho chatbot TMS.

Chỉ có 4 intent:
- smalltalk_faq
- search_device
- fuzzy_suggest
- clarify

Trả về DUY NHẤT 1 JSON:
{
  "intent": "...",
  "confidence": 0..1,
  "reason": "ngắn gọn"
}

Quy ước:
- Nếu câu chứa: đề xuất, gợi ý, phù hợp, chọn giúp → fuzzy_suggest
- Nếu chứa mã tool/holder hoặc hỏi tìm → search_device
- Câu rất ngắn, mơ hồ → clarify
""".strip()


def _extract_json(text: str) -> Optional[str]:
    m = re.search(r"\{.*\}", text, flags=re.DOTALL)
    return m.group(0) if m else None


def detect_intent(user_message: str, model: Optional[str] = None) -> Tuple[str, float, str]:
    prompt = f"{INTENT_SYSTEM}\n\nUSER:\n{user_message}\n"

    raw = call_ai(prompt, model=model)

    try:
        js = _extract_json(raw) or raw
        obj = json.loads(js)
        intent = obj.get("intent") or "clarify"
        conf = float(obj.get("confidence") or 0.5)
        reason = obj.get("reason") or ""
    except Exception:
        # fallback rule-based
        t = user_message.lower()
        if any(k in t for k in ("goi y", "de xuat", "chon", "phu hop")):
            return "fuzzy_suggest", 0.6, "rule_fuzzy"
        if any(k in t for k in ("tim", "search", "ma ", "tool", "holder", "drl-", "h-")):
            return "search_device", 0.6, "rule_search"
        return "clarify", 0.4, "parse_fail"

    return intent, max(0.0, min(conf, 1.0)), reason

# chatbot_v2/flows/fuzzy_holder_flow.py
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from holder.models import Holder

from ..contracts.constants import FUZZY_TTL_TURNS
from ..contracts.types import SessionState
from ..core.session_store import set_last_fuzzy
from ..integrations.legacy_adapters import fuzzy_start, fuzzy_followup_with_model

MIN_DURABILITY = 30  # chỉnh tuỳ bạn


def _holder_eligible(h: Holder) -> tuple[bool, str]:
    if h.trang_thai_tai_san != "san_sang":
        try:
            st = h.get_trang_thai_tai_san_display()
        except Exception:
            st = str(h.trang_thai_tai_san)
        return (False, f"Trạng thái: {st}")

    if h.mon is not None:
        try:
            v = int(h.mon)
        except Exception:
            v = None
        if v is not None and v < MIN_DURABILITY:
            return (False, f"Độ bền thấp ({v}%)")

    return (True, "")


def _filter_scored_holders(
    scored: List[Tuple[float, Any, Any]]
) -> tuple[List[Tuple[float, Holder, Any]], List[dict]]:
    ok: List[Tuple[float, Holder, Any]] = []
    rejected: List[dict] = []
    for s, dev, br in scored:
        if not isinstance(dev, Holder):
            continue
        eligible, reason = _holder_eligible(dev)
        if eligible:
            ok.append((s, dev, br))
        else:
            rejected.append(
                {
                    "code": dev.ma_noi_bo,
                    "name": dev.ten_thiet_bi,
                    "reason": reason,
                    "status": dev.trang_thai_tai_san,
                    "mon": dev.mon,
                }
            )
    ok.sort(key=lambda x: x[0], reverse=True)
    return ok, rejected


def _pack_last_fuzzy_holder(
    user_text: str,
    criteria: dict,
    scored_ok: List[Tuple[float, Holder, Any]],
    meta: dict,
) -> Dict[str, Any]:
    top = []
    for s, dev, br in scored_ok[:5]:
        top.append(
            {
                "score": round(float(s) * 100, 1),
                "name": dev.ten_thiet_bi,
                "code": dev.ma_noi_bo,
                "breakdown": br,
            }
        )

    plot = (meta.get("plot") or {}) if isinstance(meta, dict) else {}
    return {
        "ts": datetime.now().isoformat(),
        "question": user_text,
        "criteria": criteria or {},
        "top": top,
        "meta": {**(meta if isinstance(meta, dict) else {}), "plot": plot, "domain": "holder"},
    }


def start_fuzzy_holder(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    explain_fuzzy: bool = True,
    debug: bool = False,
) -> str:
    res = fuzzy_start(user_message, debug=debug, model=model)
    status = res.get("status")
    reply = res.get("message") or "Mình chưa xử lý được phần fuzzy holder."

    if status == "need_more_info":
        state["stage"] = "COLLECTING"
        state.setdefault("fuzzy", {})
        state["fuzzy"]["active"] = True
        state["fuzzy"]["description"] = user_message
        state["fuzzy"]["criteria"] = res.get("criteria") or {}
        state["fuzzy"]["turns_left"] = FUZZY_TTL_TURNS
        state["fuzzy"]["model"] = model or ""
        state["domain"] = "holder"
        return reply

    if status == "ok":
        scored_ok, rejected = _filter_scored_holders(res.get("scored") or [])

        if not scored_ok:
            lines = ["❌ Mình **không đề xuất holder nào** vì không đạt điều kiện trạng thái/độ bền."]
            if rejected:
                lines.append("Các ứng viên bị loại:")
                for r in rejected[:5]:
                    lines.append(f"- {r['code']} ({r['name']}): {r['reason']} (mon={r['mon']})")
            last = _pack_last_fuzzy_holder(user_message, res.get("criteria") or {}, [], {"rejected": rejected})
            set_last_fuzzy(request.session, state, last)
            state["stage"] = "PRESENTING"
            state.setdefault("fuzzy", {})["active"] = False
            state["domain"] = "holder"
            return "\n".join(lines)

        meta = res.get("meta") or {}
        meta = meta if isinstance(meta, dict) else {}
        meta["rejected"] = rejected

        last = _pack_last_fuzzy_holder(user_message, res.get("criteria") or {}, scored_ok, meta)
        set_last_fuzzy(request.session, state, last)

        state["stage"] = "PRESENTING"
        state.setdefault("fuzzy", {})["active"] = False
        state["domain"] = "holder"

        if rejected:
            reply += "\n\n⚠️ Một số holder bị loại do không sẵn sàng/độ bền thấp."
        return reply

    if status == "exit":
        state.setdefault("fuzzy", {})["active"] = False
        state["domain"] = "holder"
        return reply

    return reply


def followup_fuzzy_holder(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    debug: bool = False,
) -> str:
    fs = state.get("fuzzy") or {}
    criteria = fs.get("criteria") or {}
    turns_left = int(fs.get("turns_left") or FUZZY_TTL_TURNS)

    res = fuzzy_followup_with_model(
        user_message,
        {"criteria": criteria, "turns_left": turns_left},
        debug=debug,
        model=model,
    )
    status = res.get("status")
    reply = res.get("message") or "Mình chưa xử lý được phần fuzzy holder."

    if status == "need_more_info":
        fs["criteria"] = res.get("criteria") or criteria
        fs["turns_left"] = turns_left - 1
        fs["active"] = True
        state["fuzzy"] = fs
        state["stage"] = "COLLECTING"
        state["domain"] = "holder"
        return reply

    if status == "ok":
        scored_ok, rejected = _filter_scored_holders(res.get("scored") or [])
        fs["active"] = False
        state["fuzzy"] = fs
        state["stage"] = "PRESENTING"
        state["domain"] = "holder"

        if not scored_ok:
            lines = ["❌ Mình **không đề xuất holder nào** vì không đạt điều kiện trạng thái/độ bền."]
            if rejected:
                lines.append("Các ứng viên bị loại:")
                for r in rejected[:5]:
                    lines.append(f"- {r['code']} ({r['name']}): {r['reason']}")
            last = _pack_last_fuzzy_holder(fs.get("description") or user_message, res.get("criteria") or {}, [], {"rejected": rejected})
            set_last_fuzzy(request.session, state, last)
            return "\n".join(lines)

        meta = res.get("meta") or {}
        meta = meta if isinstance(meta, dict) else {}
        meta["rejected"] = rejected

        last = _pack_last_fuzzy_holder(fs.get("description") or user_message, res.get("criteria") or {}, scored_ok, meta)
        set_last_fuzzy(request.session, state, last)

        if rejected:
            reply += "\n\n⚠️ Một số holder bị loại do không sẵn sàng/độ bền thấp."
        return reply

    if status == "exit":
        fs["active"] = False
        state["fuzzy"] = fs
        state["stage"] = "IDLE"
        state["domain"] = "holder"
        return reply

    return reply

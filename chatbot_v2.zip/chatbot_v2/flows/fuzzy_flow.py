# chatbot_v2/flows/fuzzy_flow.py
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional, Tuple

from ..integrations.legacy_adapters import fuzzy_start, fuzzy_followup_with_model
from ..contracts.types import SessionState
from ..contracts.constants import FUZZY_TTL_TURNS
from ..core.session_store import set_last_fuzzy


def _pack_last_fuzzy(user_text: str, result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Chuẩn hoá last_fuzzy để template fuzzy_last.html dùng được (giống legacy).
    """
    top = []
    for s, dev, br in (result.get("scored") or [])[:5]:
        top.append(
            {
                "score": round(float(s) * 100, 1),
                "name": getattr(dev, "ten_tool", None)
                or getattr(dev, "ten_thiet_bi", None)
                or str(dev),
                "code": getattr(dev, "ma_tool", None) or getattr(dev, "ma_noi_bo", None) or "",
                "breakdown": br,
            }
        )

    meta = result.get("meta") or {}
    plot = (meta.get("plot") or {}) if isinstance(meta, dict) else {}

    return {
        "ts": datetime.now().isoformat(),
        "question": user_text,
        "criteria": result.get("criteria") or {},
        "top": top,
        "meta": {**(meta if isinstance(meta, dict) else {}), "plot": plot},
    }


def format_explain_from_last(last: Dict[str, Any]) -> Optional[str]:
    top = last.get("top") or []
    if not top:
        return None
    best = top[0]
    lines = [
        f"🔎 **Vì sao mình gợi ý `{best.get('name')}`?**",
        f"- **Điểm fuzzy tổng:** {best.get('score')}/100",
    ]
    breakdown = best.get("breakdown") or {}
    if breakdown:
        lines.append("- **Đóng góp theo tiêu chí:**")
        for k, v in sorted(breakdown.items(), key=lambda x: x[1], reverse=True):
            lines.append(f"  - {k}: {round(float(v) * 100)}%")
    lines.append("\nBạn có thể bổ sung vật liệu, kiểu gia công, đường kính, độ nhám Ra… để chấm chính xác hơn.")
    return "\n".join(lines)


def start_fuzzy(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    explain_fuzzy: bool = True,
    debug: bool = False,
) -> str:
    res = fuzzy_start(user_message, debug=debug, model=model)
    status = res.get("status")
    reply = res.get("message") or "Mình chưa xử lý được phần fuzzy."

    # bật session fuzzy nếu cần hỏi thêm
    if status == "need_more_info":
        state["stage"] = "COLLECTING"
        state.setdefault("fuzzy", {})
        state["fuzzy"]["active"] = True
        state["fuzzy"]["description"] = user_message
        state["fuzzy"]["criteria"] = res.get("criteria") or {}
        state["fuzzy"]["turns_left"] = FUZZY_TTL_TURNS
        state["fuzzy"]["model"] = model or ""

        # mirror legacy key (nếu bạn muốn giữ tương thích)
        request.session["fuzzy_state"] = {
            "description": user_message,
            "criteria": state["fuzzy"]["criteria"],
            "turns_left": FUZZY_TTL_TURNS,
            "model": model or "",
        }
        request.session.modified = True
        return reply

    if status == "ok":
        state["stage"] = "PRESENTING"
        state.setdefault("fuzzy", {})
        state["fuzzy"]["active"] = False

        last = _pack_last_fuzzy(user_message, res)
        set_last_fuzzy(request.session, state, last)

        if explain_fuzzy:
            exp = format_explain_from_last(last)
            if exp:
                reply = reply + "\n\n" + exp
        return reply

    if status == "exit":
    # user bảo dừng
        state.setdefault("fuzzy", {})
        state["fuzzy"]["active"] = False
        request.session.pop("fuzzy_state", None)
        request.session.modified = True
        return reply

    return reply


def followup_fuzzy(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    debug: bool = False,
) -> str:
    """
    Khi fuzzy đang active: lấy fuzzy_state từ v2 state (ưu tiên),
    fallback lấy từ session["fuzzy_state"].
    """
    fs = state.get("fuzzy") or {}
    criteria = fs.get("criteria") or {}
    turns_left = int(fs.get("turns_left") or FUZZY_TTL_TURNS)

    fuzzy_state = {
        "criteria": criteria,
        "turns_left": turns_left,
    }

    res = fuzzy_followup_with_model(user_message, fuzzy_state, debug=debug, model=model)
    status = res.get("status")
    reply = res.get("message") or "Mình chưa xử lý được phần fuzzy."

    if status == "need_more_info":
        fs["criteria"] = res.get("criteria") or criteria
        fs["turns_left"] = turns_left - 1
        fs["active"] = True
        state["fuzzy"] = fs
        state["stage"] = "COLLECTING"

        # mirror legacy
        request.session["fuzzy_state"] = {
            "description": fs.get("description") or "",
            "criteria": fs["criteria"],
            "turns_left": fs["turns_left"],
            "model": model or "",
        }
        request.session.modified = True
        return reply

    if status == "ok":
        fs["active"] = False
        state["fuzzy"] = fs
        state["stage"] = "PRESENTING"
        request.session.pop("fuzzy_state", None)
        request.session.modified = True

        desc = fs.get("description") or user_message
        last = _pack_last_fuzzy(desc, res)
        set_last_fuzzy(request.session, state, last)
        return reply

    if status == "exit":
        fs["active"] = False
        state["fuzzy"] = fs
        state["stage"] = "IDLE"
        request.session.pop("fuzzy_state", None)
        request.session.modified = True
        return reply

    return reply

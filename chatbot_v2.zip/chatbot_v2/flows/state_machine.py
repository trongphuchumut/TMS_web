# chatbot_v2/flows/state_machine.py
from __future__ import annotations

from typing import Optional, Any, Dict
import re

from ..contracts.constants import INTENT_CONF_THRESHOLD, FUZZY_TTL_TURNS
from ..contracts.types import SessionState, RouteResult, BotResponse
from ..routing.router import route
from ..core.text_norm import parse_yes_no_confirm, normalize_vi


# ------------------ helpers domain/action ------------------

def _detect_domain_from_text(msg: str) -> Optional[str]:
    """
    Heuristic: đoán domain từ text.
    Ưu tiên holder nếu có dấu hiệu rõ (BT/HSK/ER/collet...), còn lại nghiêng tool.
    """
    t = normalize_vi(msg)

    # holder keywords (ưu tiên mạnh)
    if re.search(r"\b(holder|do ga|do-ga|bau kep|bầu kẹp|collet|chuck|bap kep|bắp kẹp|er\d*|bt\d*|hsk\d*|cat\d*|sk\d*)\b", t):
        return "holder"

    # tool keywords
    if re.search(r"\b(tool|dao|mũi khoan|mui khoan|khoan|phay|taro|doa|tien|tiện|endmill|drill|tap|ream)\b", t):
        return "tool"

    # code pattern (tuỳ bạn: H-xxx là holder)
    if re.search(r"\bh[-_][a-z0-9]", t):
        return "holder"

    # code dạng DRL-HSS-07-GEN... thường là tool
    if re.search(r"\b[a-z]{2,}-[a-z0-9]{2,}", t):
        return "tool"

    return None


def _detect_action_from_text(msg: str) -> Optional[str]:
    """
    Heuristic: đoán user muốn search hay fuzzy.
    - fuzzy: đề xuất/gợi ý/chọn phù hợp/tối ưu/fuzzy...
    - search: tìm/tra cứu/mã/code/chi tiết/tồn kho/vị trí...
    """
    t = normalize_vi(msg)

    # fuzzy keywords
    if any(k in t for k in ("de xuat", "đề xuất", "goi y", "gợi ý", "chon", "chọn", "phu hop", "phù hợp",
                            "toi uu", "tối ưu", "fuzzy", "khuyen nghi", "khuyến nghị")):
        return "fuzzy"

    # search keywords
    if any(k in t for k in ("tim", "tìm", "tra", "trả", "tra cuu", "tra cứu", "chi tiet", "chi tiết",
                            "ton kho", "tồn kho", "vi tri", "vị trí", "o dau", "ở đâu", "ma", "mã", "code")):
        return "search"

    # nếu có mã kiểu DRL-HSS-07-GEN... nghi search
    if re.search(r"\b[a-z]{2,}-[a-z0-9]{2,}", t):
        return "search"

    return None


def _is_cancel_cmd(msg: str) -> bool:
    t = normalize_vi(msg)
    return t in ("huy", "huy bo", "huỷ", "huỷ bỏ", "cancel", "thoat", "thoát", "stop", "bo qua", "bỏ qua")


def _is_reset_cmd(msg: str) -> bool:
    t = normalize_vi(msg)
    return t in ("reset", "restart", "clear", "reset lai", "reset lại", "lam lai", "làm lại")


# ------------------ state init/reset ------------------

def _ensure_fuzzy_state(state: SessionState) -> None:
    fuzzy = state.get("fuzzy") or {}
    if "active" not in fuzzy:
        fuzzy["active"] = False
    if "criteria" not in fuzzy:
        fuzzy["criteria"] = {}
    if "turns_left" not in fuzzy:
        fuzzy["turns_left"] = FUZZY_TTL_TURNS
    if "description" not in fuzzy:
        fuzzy["description"] = ""
    if "model" not in fuzzy:
        fuzzy["model"] = ""
    state["fuzzy"] = fuzzy  # type: ignore[assignment]

    # domain: "tool" | "holder" | None
    if "domain" not in state:
        state["domain"] = None  # type: ignore[assignment]


def _reset_state(state: SessionState, request) -> None:
    state["stage"] = "IDLE"
    state["pending_question_id"] = None
    state["pending_fields"] = []
    state["pending_options"] = []
    state["search_confirm"] = None
    state["last_fuzzy"] = {}
    state["chat_history"] = []
    state["domain"] = None  # reset domain

    _ensure_fuzzy_state(state)
    state["fuzzy"]["active"] = False
    state["fuzzy"]["criteria"] = {}
    state["fuzzy"]["turns_left"] = FUZZY_TTL_TURNS
    state["fuzzy"]["description"] = ""
    state["fuzzy"]["model"] = ""

    request.session.pop("device_confirm_state", None)
    request.session.pop("fuzzy_state", None)
    request.session.pop("last_fuzzy", None)
    request.session.pop("chat_history", None)
    request.session.modified = True


def _stop_current_flow(state: SessionState, request) -> None:
    state["pending_question_id"] = None
    state["pending_fields"] = []
    state["pending_options"] = []
    state["search_confirm"] = None
    state["stage"] = "IDLE"

    _ensure_fuzzy_state(state)
    state["fuzzy"]["active"] = False

    request.session.pop("device_confirm_state", None)
    request.session.pop("fuzzy_state", None)
    request.session.modified = True


# ------------------ menus (2 tầng) ------------------

def _ask_pick_domain(state: SessionState) -> str:
    state["pending_question_id"] = "Q_DOMAIN_PICK"
    state["pending_options"] = ["tool", "holder"]
    return (
        "Bạn muốn làm việc với loại nào? 🧰\n"
        "1) **Tool** (dao/mũi khoan/dao phay...)\n"
        "2) **Holder** (đồ gá/bầu kẹp/collet...)\n"
        "Trả lời **1** hoặc **2** nhé."
    )


def _ask_pick_action(state: SessionState) -> str:
    dom = state.get("domain")
    state["pending_question_id"] = "Q_ACTION_PICK"
    state["pending_options"] = ["search", "fuzzy"]
    if dom == "tool":
        return (
            "Ok, bạn chọn **Tool** ✅\n"
            "1) **Tìm Tool** trong kho (mã/tên)\n"
            "2) **Đề xuất Tool theo fuzzy**\n"
            "Trả lời **1** hoặc **2** nhé."
        )
    if dom == "holder":
        return (
            "Ok, bạn chọn **Holder** ✅\n"
            "1) **Tìm Holder** trong kho (mã/tên)\n"
            "2) **Đề xuất Holder theo fuzzy**\n"
            "Trả lời **1** hoặc **2** nhé."
        )
    return _ask_pick_domain(state)


def _handle_domain_pick_choice(state: SessionState, idx: int) -> str:
    if idx == 1:
        state["domain"] = "tool"  # type: ignore[assignment]
    elif idx == 2:
        state["domain"] = "holder"  # type: ignore[assignment]
    else:
        return "Ở bước này bạn chỉ cần trả lời **1** hoặc **2** nhé."
    return _ask_pick_action(state)


def _handle_action_pick_choice(state: SessionState, idx: int) -> str:
    state["pending_question_id"] = None
    state["pending_options"] = []
    dom = state.get("domain")

    if idx == 1:
        state["stage"] = "IDLE"
        if dom == "tool":
            return "Ok. Bạn gửi mình **mã/tên tool** nhé. Ví dụ: `DRL-HSS-07-GEN`."
        if dom == "holder":
            return "Ok. Bạn gửi mình **mã/tên holder** nhé. Ví dụ: `H-xxx`."
        return _ask_pick_domain(state)

    if idx == 2:
        state["stage"] = "COLLECTING"
        if dom == "tool":
            return (
                "Ok. Bạn mô tả yêu cầu để mình chấm **fuzzy tool** nhé.\n"
                "Ví dụ: vật liệu, kiểu gia công, đường kính, Ra, dung sai…"
            )
        if dom == "holder":
            return (
                "Ok. Bạn mô tả yêu cầu để mình chấm **fuzzy holder** nhé.\n"
                "Ví dụ: chuẩn BT/HSK/SK, ER size, đường kính kẹp, độ cứng vững…"
            )
        return _ask_pick_domain(state)

    return "Ở bước này bạn chỉ cần trả lời **1** hoặc **2** nhé."


# ------------------ confirm sync ------------------

def _sync_legacy_search_confirm_into_state(request, state: SessionState) -> None:
    sc = state.get("search_confirm")
    if isinstance(sc, dict) and sc:
        return
    legacy = request.session.get("device_confirm_state")
    if isinstance(legacy, dict) and legacy:
        state["search_confirm"] = legacy


def _is_search_confirm_active(request, state: SessionState) -> bool:
    sc = state.get("search_confirm")
    if isinstance(sc, dict) and sc:
        return True
    legacy = request.session.get("device_confirm_state")
    return isinstance(legacy, dict) and bool(legacy)


# ------------------ select / add_info / explain ------------------

def _handle_select_case(request, state: SessionState, payload: Dict[str, Any]) -> str:
    by = payload.get("by")
    _ensure_fuzzy_state(state)

    if state.get("pending_question_id") == "Q_DOMAIN_PICK" and by == "index":
        idx = int(payload.get("index") or 0)
        return _handle_domain_pick_choice(state, idx)

    if state.get("pending_question_id") == "Q_ACTION_PICK" and by == "index":
        idx = int(payload.get("index") or 0)
        return _handle_action_pick_choice(state, idx)

    # chọn theo mã
    if by == "tool_code":
        code = (payload.get("code") or "").strip()
        state["domain"] = "tool"  # type: ignore[assignment]
        from ..flows.search_tool_flow import handle_search_tool
        return handle_search_tool(request, code, state)

    if by == "holder_code":
        code = (payload.get("code") or "").strip()
        state["domain"] = "holder"  # type: ignore[assignment]
        from ..flows.search_holder_flow import handle_search_holder
        return handle_search_holder(request, code, state)

    # chọn index nhưng không có list
    if by == "index":
        # AI-first: thay vì hỏi domain lại hoài, hỏi action theo domain nếu có
        if state.get("domain"):
            return _ask_pick_action(state)
        return _ask_pick_domain(state)

    return "Mình chưa hiểu lựa chọn của bạn. Bạn thử nói rõ hơn nhé."


def _handle_add_info_case(request, state: SessionState, payload: Dict[str, Any], model: Optional[str]) -> str:
    _ensure_fuzzy_state(state)
    # fuzzy đang active -> follow-up sẽ xử lý ở phần handle_message (ưu tiên)
    if state["fuzzy"].get("active"):
        return "Ok, mình nhận rồi. Để mình cập nhật tiêu chí và chấm tiếp…"

    # fuzzy chưa active -> AI-first: đừng hỏi domain ngay, hỏi action theo domain (nếu có)
    if state.get("domain"):
        return _ask_pick_action(state)
    return _ask_pick_domain(state)


def _handle_ask_explain_case(state: SessionState) -> str:
    last = state.get("last_fuzzy") or {}
    top = last.get("top") or []
    if not top:
        return "Mình chưa có kết quả fuzzy gần nhất để giải thích. Bạn thử chạy fuzzy trước nhé."

    it = top[0]  # ✅ auto giải thích cái #1
    name = it.get("name") or it.get("ten") or "?"
    code = it.get("code") or it.get("ma") or ""
    score = it.get("score")

    ex = it.get("explain") or {}
    inputs = ex.get("inputs") or {}
    norm = ex.get("norm") or {}
    crit = ex.get("criteria_scores") or {}
    w = ex.get("weights") or {}
    memb = ex.get("membership") or {}
    reasons = ex.get("reasons") or []

    lines = []
    lines.append(f"🔎 Giải thích chi tiết vì sao mình chọn **#1**: `{name}`" + (f" ({code})" if code else ""))
    lines.append(f"- **Điểm fuzzy tổng:** **{score}/100**")

    if inputs:
        lines.append("\n**1) Dữ liệu đầu vào mình hiểu được:**")
        for k, v in inputs.items():
            lines.append(f"- {k}: `{v}`")

    if norm:
        lines.append("\n**2) Chuẩn hoá (0..1) để chấm fuzzy:**")
        for k, v in norm.items():
            try:
                lines.append(f"- {k}: **{float(v):.2f}**")
            except Exception:
                lines.append(f"- {k}: `{v}`")

    if crit:
        lines.append("\n**3) Điểm theo từng tiêu chí:**")
        # sort theo weight nếu có
        keys = list(crit.keys())
        if w:
            keys.sort(key=lambda kk: float(w.get(kk) or 0), reverse=True)
        for k in keys:
            wt = w.get(k)
            if wt is not None:
                lines.append(f"- {k}: **{crit[k]}**  (weight={wt})")
            else:
                lines.append(f"- {k}: **{crit[k]}**")

    if memb:
        lines.append("\n**4) Membership (mức thuộc) theo từng biến:**")
        # memb dạng dict: var -> {label: value}
        for var, m in memb.items():
            if isinstance(m, dict):
                parts = []
                for lab, val in m.items():
                    try:
                        parts.append(f"{lab}={float(val):.2f}")
                    except Exception:
                        parts.append(f"{lab}={val}")
                lines.append(f"- {var}: " + ", ".join(parts))

    if reasons:
        lines.append("\n**5) Kết luận lý do chọn:**")
        for r in reasons:
            lines.append(f"- {r}")

    # fallback nếu explain rỗng
    if not (inputs or norm or crit or memb or reasons):
        lines.append("\n⚠️ Hiện mình chưa lưu breakdown cho lượt chấm này.")
        lines.append("Muốn giải thích cặn kẽ thì cần lưu `top[0].explain` (criteria_scores/weights/reasons...) khi chạy fuzzy.")

    return "\n".join(lines)

# ===================== MAIN =====================

def handle_message(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    explain_fuzzy: bool = True,
    debug: bool = False,
) -> BotResponse:
    _ensure_fuzzy_state(state)
    msg = (user_message or "").strip()

    # ✅ auto-detect domain nếu user có nói rõ (giữ domain xuyên suốt)
    dom = _detect_domain_from_text(msg)
    if dom:
        state["domain"] = dom  # type: ignore[assignment]

    # ✅ sync legacy confirm
    _sync_legacy_search_confirm_into_state(request, state)

    # ✅ ESCAPE HATCH: reset/hủy luôn ưu tiên, kể cả đang confirm
    if _is_reset_cmd(msg):
        _reset_state(state, request)
        return {"reply": "Đã reset phiên chatbot ✅ Bạn mô tả yêu cầu lại từ đầu nhé.", "state": state}

    if _is_cancel_cmd(msg):
        _stop_current_flow(state, request)
        return {"reply": "Ok, mình đã dừng luồng hiện tại ✅ Bạn muốn làm gì tiếp theo?", "state": state}

    # ✅ AI-first shortcut: nếu trong câu đã rõ search/fuzzy thì chạy thẳng (không menu)
    act0 = _detect_action_from_text(msg)
    if act0 == "search":
        # nếu chưa đoán được domain, mặc định tool
        if not state.get("domain"):
            state["domain"] = _detect_domain_from_text(msg) or "tool"  # type: ignore[assignment]

        if state.get("domain") == "holder":
            from ..flows.search_holder_flow import handle_search_holder
            reply = handle_search_holder(request, msg, state)
            return {"reply": reply, "state": state}
        else:
            from ..flows.search_tool_flow import handle_search_tool
            reply = handle_search_tool(request, msg, state)
            return {"reply": reply, "state": state}

    if act0 == "fuzzy":
        if not state.get("domain"):
            state["domain"] = _detect_domain_from_text(msg) or "tool"  # type: ignore[assignment]
        state["stage"] = "COLLECTING"

        if state.get("domain") == "holder":
            from ..flows.fuzzy_holder_flow import start_fuzzy_holder
            reply = start_fuzzy_holder(request, msg, state, model=model, explain_fuzzy=explain_fuzzy, debug=debug)
            return {"reply": reply, "state": state}
        else:
            from ..flows.fuzzy_tool_flow import start_fuzzy_tool
            reply = start_fuzzy_tool(request, msg, state, model=model, explain_fuzzy=explain_fuzzy, debug=debug)
            return {"reply": reply, "state": state}

    # ✅ 1) Search confirm gate (đi riêng tool/holder)
    if _is_search_confirm_active(request, state):
        yn = parse_yes_no_confirm(msg)
        if yn is None:
            return {
                "reply": "Mình đang chờ **xác nhận** 😅 Bạn trả lời **đúng/không** nha.",
                "state": state,
            }

        # domain quyết định yesno handler
        if state.get("domain") == "holder":
            from ..flows.search_holder_flow import handle_search_holder_yesno
            reply = handle_search_holder_yesno(request, msg, state, yes=(yn == "yes"))
            return {"reply": reply, "state": state}

        # default tool
        from ..flows.search_tool_flow import handle_search_tool_yesno
        reply = handle_search_tool_yesno(request, msg, state, yes=(yn == "yes"))
        return {"reply": reply, "state": state}

    # ✅ 2) menu chọn domain/action (bắt trực tiếp 1/2)
    if state.get("pending_question_id") == "Q_DOMAIN_PICK" and msg in ("1", "2"):
        reply = _handle_domain_pick_choice(state, int(msg))
        return {"reply": reply, "state": state}

    if state.get("pending_question_id") == "Q_ACTION_PICK" and msg in ("1", "2"):
        reply = _handle_action_pick_choice(state, int(msg))
        return {"reply": reply, "state": state}

    # ✅ 3) FUZZY follow-up: đi đúng flow theo domain
    if state.get("fuzzy", {}).get("active"):
        if state.get("domain") == "holder":
            from ..flows.fuzzy_holder_flow import followup_fuzzy_holder
            reply = followup_fuzzy_holder(request, msg, state, model=model, debug=debug)
            return {"reply": reply, "state": state}
        else:
            from ..flows.fuzzy_tool_flow import followup_fuzzy_tool
            reply = followup_fuzzy_tool(request, msg, state, model=model, debug=debug)
            return {"reply": reply, "state": state}

    # ✅ 3.5) Nếu user đã chọn "fuzzy" (stage=COLLECTING) mà fuzzy chưa active
    # thì auto start fuzzy theo domain, không hỏi menu nữa
    if state.get("stage") == "COLLECTING" and not state.get("fuzzy", {}).get("active"):
        if not state.get("domain"):
            state["domain"] = _detect_domain_from_text(msg) or "tool"  # type: ignore[assignment]

        if state.get("domain") == "holder":
            from ..flows.fuzzy_holder_flow import start_fuzzy_holder
            reply = start_fuzzy_holder(
                request, msg, state, model=model, explain_fuzzy=explain_fuzzy, debug=debug
            )
            return {"reply": reply, "state": state}
        else:
            from ..flows.fuzzy_tool_flow import start_fuzzy_tool
            reply = start_fuzzy_tool(
                request, msg, state, model=model, explain_fuzzy=explain_fuzzy, debug=debug
            )
            return {"reply": reply, "state": state}

    # ✅ 4) route bình thường
    r: RouteResult = route(msg, state, model=model)

    # ✅ ăn payload domain/code nếu router có gửi (AI-first)
    payload0 = r.get("payload") or {}
    if payload0.get("domain") and not state.get("domain"):
        state["domain"] = payload0["domain"]  # type: ignore[assignment]

    # ===================== CASES =====================
    if r.get("kind") == "case":
        t = r.get("type")
        payload = r.get("payload") or {}

        if t == "RESET":
            _reset_state(state, request)
            return {"reply": "Đã reset phiên chatbot ✅ Bạn mô tả yêu cầu lại từ đầu nhé.", "state": state}

        if t == "CANCEL":
            _stop_current_flow(state, request)
            return {"reply": "Ok, mình đã dừng luồng hiện tại ✅ Bạn muốn làm gì tiếp theo?", "state": state}

        if t == "AMBIGUOUS_CONFIRM":
            # AI-first: nếu đã có domain thì hỏi action; chưa có thì mới hỏi domain
            if state.get("domain"):
                return {"reply": _ask_pick_action(state), "state": state}
            return {"reply": _ask_pick_domain(state), "state": state}

        if t in ("CONFIRM_YES", "CONFIRM_NO"):
            return {
                "reply": (
                    "Mình thấy bạn trả lời **đúng/không**, nhưng hiện không có bước xác nhận nào đang chờ.\n"
                    "Bạn gửi câu rõ hơn (tìm mã / đề xuất) giúp mình nhé."
                ),
                "state": state,
            }

        if t == "SELECT":
            reply = _handle_select_case(request, state, payload)
            return {"reply": reply, "state": state}

        if t == "ADD_INFO":
            reply = _handle_add_info_case(request, state, payload, model=model)
            return {"reply": reply, "state": state}

        if t == "ASK_EXPLAIN":
            reply = _handle_ask_explain_case(state)
            return {"reply": reply, "state": state}

        return {"reply": "Mình đã nhận yêu cầu, nhưng chưa có handler cho trường hợp này.", "state": state}

    # ===================== INTENTS =====================
    intent = r.get("type") or "clarify"
    conf = float(r.get("confidence") or 0)
    payload = r.get("payload") or {}

    # ✅ AI-first: nếu chưa có domain thì tự đoán, không ép menu sớm
    if not state.get("domain"):
        guessed = _detect_domain_from_text(msg)
        if guessed:
            state["domain"] = guessed  # type: ignore[assignment]
        else:
            state["domain"] = "tool"  # type: ignore[assignment]

    # intent mơ hồ -> AI-first: thử đoán action trước, nếu đoán được thì chạy luôn
    if intent == "clarify" or conf < INTENT_CONF_THRESHOLD:
        act = _detect_action_from_text(msg)

        if act == "search":
            if state.get("domain") == "holder":
                from ..flows.search_holder_flow import handle_search_holder
                q = (payload.get("code") or msg)
                reply = handle_search_holder(request, q, state)
                return {"reply": reply, "state": state}
            else:
                from ..flows.search_tool_flow import handle_search_tool
                q = (payload.get("code") or msg)
                reply = handle_search_tool(request, q, state)
                return {"reply": reply, "state": state}

        if act == "fuzzy":
            state["stage"] = "COLLECTING"
            if state.get("domain") == "holder":
                from ..flows.fuzzy_holder_flow import start_fuzzy_holder
                reply = start_fuzzy_holder(request, msg, state, model=model, explain_fuzzy=explain_fuzzy, debug=debug)
                return {"reply": reply, "state": state}
            else:
                from ..flows.fuzzy_tool_flow import start_fuzzy_tool
                reply = start_fuzzy_tool(request, msg, state, model=model, explain_fuzzy=explain_fuzzy, debug=debug)
                return {"reply": reply, "state": state}

        # nếu vẫn mơ hồ thật -> hỏi action theo domain (menu cuối cùng)
        return {"reply": _ask_pick_action(state), "state": state}

    if intent == "smalltalk_faq":
        from ..flows import smalltalk_flow
        reply = smalltalk_flow.handle_smalltalk(msg, state.get("chat_history") or [], model=model)
        return {"reply": reply, "state": state}

    # search/fuzzy tách theo domain (dù router chưa tách intent)
    if intent == "search_device":
        q = (payload.get("code") or msg)
        if state.get("domain") == "holder":
            from ..flows.search_holder_flow import handle_search_holder
            reply = handle_search_holder(request, q, state)
            return {"reply": reply, "state": state}
        else:
            from ..flows.search_tool_flow import handle_search_tool
            reply = handle_search_tool(request, q, state)
            return {"reply": reply, "state": state}

    if intent == "fuzzy_suggest":
        if state.get("domain") == "holder":
            from ..flows.fuzzy_holder_flow import start_fuzzy_holder
            reply = start_fuzzy_holder(request, msg, state, model=model, explain_fuzzy=explain_fuzzy, debug=debug)
            return {"reply": reply, "state": state}
        else:
            from ..flows.fuzzy_tool_flow import start_fuzzy_tool
            reply = start_fuzzy_tool(request, msg, state, model=model, explain_fuzzy=explain_fuzzy, debug=debug)
            return {"reply": reply, "state": state}

    # fallback
    return {"reply": _ask_pick_action(state), "state": state}

# chatbot_v2/flows/fuzzy_tool_flow.py
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from tool.models import Tool

from ..contracts.constants import FUZZY_TTL_TURNS
from ..contracts.types import SessionState
from ..core.session_store import set_last_fuzzy
from ..integrations.legacy_adapters import fuzzy_start, fuzzy_followup_with_model


def _tool_eligible(t: Tool) -> tuple[bool, str]:
    # Không đề xuất nếu không đủ tồn kho
    if (t.ton_kho or 0) <= 0:
        return (False, "Hết tồn kho")
    if t.muc_canh_bao is not None and t.ton_kho <= t.muc_canh_bao:
        return (False, f"Tồn kho thấp (≤ cảnh báo {t.muc_canh_bao})")
    return (True, "")


def _filter_scored_tools(
    scored: List[Tuple[float, Any, Any]]
) -> tuple[List[Tuple[float, Tool, Any]], List[dict]]:
    ok: List[Tuple[float, Tool, Any]] = []
    rejected: List[dict] = []
    for s, dev, br in scored:
        if not isinstance(dev, Tool):
            continue
        eligible, reason = _tool_eligible(dev)
        if eligible:
            ok.append((s, dev, br))
        else:
            rejected.append(
                {
                    "code": dev.ma_tool,
                    "name": dev.ten_tool,
                    "reason": reason,
                    "stock": dev.ton_kho,
                    "warn": dev.muc_canh_bao,
                }
            )
    ok.sort(key=lambda x: x[0], reverse=True)
    return ok, rejected


def _pack_last_fuzzy_tool(
    user_text: str,
    criteria: dict,
    scored_ok: List[Tuple[float, Tool, Any]],
    meta: dict,
) -> Dict[str, Any]:
    top = []
    for s, dev, br in scored_ok[:5]:
        top.append(
            {
                "score": round(float(s) * 100, 1),
                "name": dev.ten_tool,
                "code": dev.ma_tool,
                "breakdown": br,
            }
        )

    plot = (meta.get("plot") or {}) if isinstance(meta, dict) else {}
    return {
        "ts": datetime.now().isoformat(),
        "question": user_text,
        "criteria": criteria or {},
        "top": top,
        "meta": {**(meta if isinstance(meta, dict) else {}), "plot": plot, "domain": "tool"},
    }


def start_fuzzy_tool(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    explain_fuzzy: bool = True,
    debug: bool = False,
) -> str:
    res = fuzzy_start(user_message, debug=debug, model=model)
    status = res.get("status")
    reply = res.get("message") or "Mình chưa xử lý được phần fuzzy tool."

    if status == "need_more_info":
        state["stage"] = "COLLECTING"
        state.setdefault("fuzzy", {})
        state["fuzzy"]["active"] = True
        state["fuzzy"]["description"] = user_message
        state["fuzzy"]["criteria"] = res.get("criteria") or {}
        state["fuzzy"]["turns_left"] = FUZZY_TTL_TURNS
        state["fuzzy"]["model"] = model or ""
        state["domain"] = "tool"
        return reply

    if status == "ok":
        scored_ok, rejected = _filter_scored_tools(res.get("scored") or [])

        if not scored_ok:
            lines = ["❌ Mình **không đề xuất tool nào** vì không đạt điều kiện tồn kho."]
            if rejected:
                lines.append("Các ứng viên bị loại:")
                for r in rejected[:5]:
                    lines.append(
                        f"- {r['code']} ({r['name']}): {r['reason']} "
                        f"(tồn {r['stock']}, cảnh báo {r['warn']})"
                    )
            last = _pack_last_fuzzy_tool(user_message, res.get("criteria") or {}, [], {"rejected": rejected})
            set_last_fuzzy(request.session, state, last)
            state["stage"] = "PRESENTING"
            state.setdefault("fuzzy", {})["active"] = False
            state["domain"] = "tool"
            return "\n".join(lines)

        meta = res.get("meta") or {}
        meta = meta if isinstance(meta, dict) else {}
        meta["rejected"] = rejected

        last = _pack_last_fuzzy_tool(user_message, res.get("criteria") or {}, scored_ok, meta)
        set_last_fuzzy(request.session, state, last)

        state["stage"] = "PRESENTING"
        state.setdefault("fuzzy", {})["active"] = False
        state["domain"] = "tool"

        if rejected:
            reply += "\n\n⚠️ Một số tool bị loại do tồn kho thấp/hết kho."
        return reply

    if status == "exit":
        state.setdefault("fuzzy", {})["active"] = False
        state["domain"] = "tool"
        return reply

    return reply


def followup_fuzzy_tool(
    request,
    user_message: str,
    state: SessionState,
    model: Optional[str] = None,
    debug: bool = False,
) -> str:
    fs = state.get("fuzzy") or {}
    criteria = fs.get("criteria") or {}
    turns_left = int(fs.get("turns_left") or FUZZY_TTL_TURNS)

    res = fuzzy_followup_with_model(
        user_message,
        {"criteria": criteria, "turns_left": turns_left},
        debug=debug,
        model=model,
    )
    status = res.get("status")
    reply = res.get("message") or "Mình chưa xử lý được phần fuzzy tool."

    if status == "need_more_info":
        fs["criteria"] = res.get("criteria") or criteria
        fs["turns_left"] = turns_left - 1
        fs["active"] = True
        state["fuzzy"] = fs
        state["stage"] = "COLLECTING"
        state["domain"] = "tool"
        return reply

    if status == "ok":
        scored_ok, rejected = _filter_scored_tools(res.get("scored") or [])
        fs["active"] = False
        state["fuzzy"] = fs
        state["stage"] = "PRESENTING"
        state["domain"] = "tool"

        if not scored_ok:
            lines = ["❌ Mình **không đề xuất tool nào** vì không đạt điều kiện tồn kho."]
            if rejected:
                lines.append("Các ứng viên bị loại:")
                for r in rejected[:5]:
                    lines.append(f"- {r['code']} ({r['name']}): {r['reason']}")
            last = _pack_last_fuzzy_tool(fs.get("description") or user_message, res.get("criteria") or {}, [], {"rejected": rejected})
            set_last_fuzzy(request.session, state, last)
            return "\n".join(lines)

        meta = res.get("meta") or {}
        meta = meta if isinstance(meta, dict) else {}
        meta["rejected"] = rejected

        last = _pack_last_fuzzy_tool(fs.get("description") or user_message, res.get("criteria") or {}, scored_ok, meta)
        set_last_fuzzy(request.session, state, last)

        if rejected:
            reply += "\n\n⚠️ Một số tool bị loại do tồn kho thấp/hết kho."
        return reply

    if status == "exit":
        fs["active"] = False
        state["fuzzy"] = fs
        state["stage"] = "IDLE"
        state["domain"] = "tool"
        return reply

    return reply

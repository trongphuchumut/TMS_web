# chatbot_v2/flows/fallback_flow.py
from __future__ import annotations

from ..contracts.types import SessionState


def ask_pick_route(state: SessionState) -> str:
    state["pending_question_id"] = "Q_ROUTE_PICK"
    state["pending_fields"] = []
    state["pending_options"] = ["search_device", "fuzzy_suggest"]
    return (
        "Mình chưa chắc ý bạn 🤔\n"
        "Bạn muốn:\n"
        "1) **Tìm thiết bị trong kho** (theo mã/tên)\n"
        "2) **Đề xuất theo fuzzy** (chọn tool/holder phù hợp)\n"
        "Trả lời **1** hoặc **2** nhé."
    )

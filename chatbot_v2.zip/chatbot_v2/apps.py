from django.apps import AppConfig


class ChatbotV2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chatbot_v2'

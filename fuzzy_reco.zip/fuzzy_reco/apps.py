from django.apps import AppConfig


class FuzzyRecoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fuzzy_reco'

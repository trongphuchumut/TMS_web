from typing import Dict, Any, List
from holder.models import Holder

from ..shared.utils import clamp, safe_float, norm_percent_good
from ..shared.contracts import engine_result
from .selector import select_holder_candidates

ENGINE_VERSION = "holder_fuzzy_v1"

def _feature_scores(h: Holder) -> Dict[str, Any]:
    # cv, dx thường là decimal; giả định thang 0..10 hoặc 0..5? -> normalize nhẹ:
    # v1: clamp trực tiếp về 0..10 (nếu DB đang 0..10 là chuẩn)
    cv = clamp(safe_float(h.cv, 5.0), 0.0, 10.0)
    dx = clamp(safe_float(h.dx, 5.0), 0.0, 10.0)

    # mon: % mòn. muốn "còn tốt" = 100 - mon
    wear = None if h.mon is None else clamp(float(h.mon), 0.0, 100.0)
    remaining = None if wear is None else (100.0 - wear)
    remaining10 = norm_percent_good(remaining)  # 0..10

    # tan_suat: lần/tháng, càng thấp càng tốt (v1 normalize bằng threshold)
    ts = safe_float(h.tan_suat, 0.0)
    # 0 lần/tháng -> 10 điểm, >= 30 -> 0 điểm
    ts_score = clamp(10.0 - (ts / 3.0), 0.0, 10.0)

    # ld: càng thấp càng tốt (giả định mm, normalize thô)
    ld = safe_float(h.ld, 0.0)
    # 0 -> 10, 200mm -> 0
    ld_score = clamp(10.0 - (ld / 20.0), 0.0, 10.0)

    def fb(x): return 5.0 if x is None else float(x)

    return {
        "cv": fb(cv),
        "dx": fb(dx),
        "remaining": fb(remaining10),
        "tan_suat": fb(ts_score),
        "ld": fb(ld_score),
        "status": h.trang_thai_tai_san,
    }

def score_holder_candidates(inputs: Dict[str, Any]) -> Dict[str, Any]:
    # tạm reuse keys hiện tại chatbot đang dùng
    cost_level = clamp(safe_float(inputs.get("cost_level"), 5.0), 0.0, 10.0)
    precision = clamp(safe_float(inputs.get("precision_importance"), 5.0), 0.0, 10.0)
    durability = clamp(safe_float(inputs.get("durability_importance"), 5.0), 0.0, 10.0)
    speed = clamp(safe_float(inputs.get("speed_importance"), 5.0), 0.0, 10.0)

    # Holder: cost không có diem_gia sẵn, v1 chỉ dùng làm "không phạt" (sau bạn có thể thêm field)
    prefer_quality = (precision + durability) / 2.0

    # weights v1
    w_cv = 0.30
    w_dx = 0.30
    w_remain = 0.22
    w_ld = 0.10
    w_ts = 0.08

    rules_fired: List[str] = []
    if precision >= 7: rules_fired.append("Prefer accuracy: prioritize dx")
    if durability >= 7: rules_fired.append("Prefer low wear: prioritize remaining (100-mon)")
    if speed >= 7: rules_fired.append("Prefer stability: prioritize cv and short ld")

    ranked = []
    qs = select_holder_candidates(limit=80)

    for h in qs:
        fs = _feature_scores(h)

        # status bonus
        status_bonus = 0.0
        if fs["status"] == "san_sang":
            status_bonus = 1.0
        elif fs["status"] in ("dang_bao_tri", "ngung_su_dung"):
            status_bonus = -4.0

        # match degrees
        score_cv = fs["cv"] * (speed / 10.0)              # speed -> cứng vững/ổn định
        score_dx = fs["dx"] * (precision / 10.0)
        score_rem = fs["remaining"] * (durability / 10.0)
        score_ld = fs["ld"] * (speed / 10.0)
        score_ts = fs["tan_suat"] * (prefer_quality / 10.0)

        raw10 = (
            w_cv * score_cv +
            w_dx * score_dx +
            w_remain * score_rem +
            w_ld * score_ld +
            w_ts * score_ts
        )
        raw10 = raw10 + status_bonus
        raw10 = clamp(raw10, 0.0, 10.0)
        final = raw10 * 10.0

        ranked.append({
            "id": h.id,
            "code": h.ma_noi_bo,
            "name": h.ten_thiet_bi,
            "score": round(final, 2),
            "meta": {
                "chuan_ga": h.chuan_ga,
                "loai_kep": h.loai_kep,
                "duong_kinh_kep_max": str(h.duong_kinh_kep_max) if h.duong_kinh_kep_max is not None else None,
                "status": h.trang_thai_tai_san,
            }
        })

    ranked.sort(key=lambda x: x["score"], reverse=True)
    ranked = ranked[:10]

    breakdown = {
        "weights": {"cv": w_cv, "dx": w_dx, "remaining": w_remain, "ld": w_ld, "tan_suat": w_ts},
        "notes": [
            "v1 maps Holder.cv/dx/mon/tan_suat/ld into 0..10 features.",
            "cost_level is currently not used for Holder scoring (no price fuzzy field). Add later if needed.",
        ]
    }

    return engine_result("holder", ENGINE_VERSION, inputs, ranked, rules_fired, breakdown)

from typing import Dict, Any, List
from tool.models import Tool

from ..shared.utils import (
    clamp, safe_float,
    norm_1to5_to_0to10, inv_norm_1to5_to_0to10
)
from ..shared.contracts import engine_result
from .selector import select_tool_candidates

ENGINE_VERSION = "tool_fuzzy_v1"

def _feature_scores(t: Tool) -> Dict[str, Any]:
    """
    Convert DB fields -> 0..10 features
    """
    cheapness = inv_norm_1to5_to_0to10(t.diem_gia)           # rẻ -> điểm cao
    durability = norm_1to5_to_0to10(t.diem_do_ben)
    stability = norm_1to5_to_0to10(t.diem_on_dinh)
    surface = norm_1to5_to_0to10(t.diem_chat_luong_be_mat)
    availability = norm_1to5_to_0to10(t.diem_san_co)

    # fallback nếu thiếu điểm (None) -> set 5 để không phá
    def fb(x): return 5.0 if x is None else float(x)

    return {
        "cheapness": fb(cheapness),
        "durability": fb(durability),
        "stability": fb(stability),
        "surface": fb(surface),
        "availability": fb(availability),
        "stock": float(t.ton_kho or 0),
    }

def score_tool_candidates(inputs: Dict[str, Any]) -> Dict[str, Any]:
    """
    inputs: dict 0..10 (từ chatbot/AI parse)
    """
    cost_level = clamp(safe_float(inputs.get("cost_level"), 5.0), 0.0, 10.0)
    precision = clamp(safe_float(inputs.get("precision_importance"), 5.0), 0.0, 10.0)
    durability = clamp(safe_float(inputs.get("durability_importance"), 5.0), 0.0, 10.0)
    speed = clamp(safe_float(inputs.get("speed_importance"), 5.0), 0.0, 10.0)

    # User muốn rẻ => cost_level thấp. Convert thành "prefer cheap" cao.
    prefer_cheap = 10.0 - cost_level

    # trọng số v1 (có thể chỉnh sau)
    w_cheap = 0.30
    w_dura  = 0.28
    w_prec  = 0.22
    w_speed = 0.12
    w_avail = 0.08

    rules_fired: List[str] = []
    if prefer_cheap >= 7: rules_fired.append("Prefer cheap: prioritize low diem_gia")
    if durability >= 7: rules_fired.append("Prefer durability: prioritize diem_do_ben")
    if precision >= 7: rules_fired.append("Prefer precision: prioritize diem_chat_luong_be_mat")
    if speed >= 7: rules_fired.append("Prefer speed: prioritize diem_on_dinh & availability")

    ranked = []
    qs = select_tool_candidates(limit=80)

    for t in qs:
        fs = _feature_scores(t)

        # match degree (0..1) cho từng tiêu chí
        # cheap: user prefer_cheap cao -> reward cheapness cao
        score_cheap = fs["cheapness"] * (prefer_cheap / 10.0)
        score_dura  = fs["durability"] * (durability / 10.0)
        score_prec  = fs["surface"] * (precision / 10.0)
        score_speed = fs["stability"] * (speed / 10.0)
        score_avail = fs["availability"]

        # Bonus tồn kho
        stock_bonus = 0.0
        if fs["stock"] > 0:
            stock_bonus = 1.0
        else:
            stock_bonus = -3.0  # hết hàng thì tụt

        # tổng điểm 0..10 trước, rồi scale 0..100
        raw10 = (
            w_cheap * score_cheap +
            w_dura  * score_dura  +
            w_prec  * score_prec  +
            w_speed * score_speed +
            w_avail * score_avail
        )
        raw10 = raw10 + stock_bonus
        raw10 = clamp(raw10, 0.0, 10.0)
        final = raw10 * 10.0

        ranked.append({
            "id": t.id,
            "code": t.ma_tool,
            "name": t.ten_tool,
            "score": round(final, 2),
            "meta": {
                "ton_kho": t.ton_kho,
                "nhom_tool": t.nhom_tool,
                "dong_tool": t.dong_tool,
            }
        })

    ranked.sort(key=lambda x: x["score"], reverse=True)
    ranked = ranked[:10]

    breakdown = {
        "weights": {"cheap": w_cheap, "durability": w_dura, "precision": w_prec, "speed": w_speed, "availability": w_avail},
        "user_preference": {"prefer_cheap": prefer_cheap, "durability": durability, "precision": precision, "speed": speed},
        "notes": [
            "v1 uses Tool.diem_* (1..5) mapped to 0..10 features.",
            "precision is temporarily mapped to surface_quality; you can later split into on_dinh/quality separately.",
        ]
    }

    return engine_result("tool", ENGINE_VERSION, inputs, ranked, rules_fired, breakdown)

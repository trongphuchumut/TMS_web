# iot_gateway/management/__init__.py
# Để Django nhận đây là package Python

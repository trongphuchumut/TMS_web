# iot_gateway/__init__.py
default_app_config = "iot_gateway.apps.IotGatewayConfig"
